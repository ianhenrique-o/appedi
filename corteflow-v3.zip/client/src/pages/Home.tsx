import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Captions, Download, Film, Keyboard, Layers, Loader2, Palette, Pause, Play, Redo2, Scissors, SkipBack, Type, Undo2, Upload, X, ZoomIn,
} from "lucide-react";
import type { FramingKey, Insert, MediaInfo, ProjectInfo, Range, RenderRequest, Suggestion, TranscriptState, ZoomRange } from "@shared/editor";
import { emphasisFlags, formatTime, inRanges, mapToSource, outputTimeAt } from "@shared/editor";
import { getConfig, getProject, getTranscript, retryTranscript, uploadMedia, uploadVideo, type ServerConfig } from "@/editor/api";
import { CaptionsPanel, CutsPanel, InsertsPanel, StylePanel, TextPanel, type FramingStatus } from "@/editor/Panels";
import { trackFace } from "@/editor/faceTrack";
import ExportDialog from "@/editor/ExportDialog";
import Preview from "@/editor/Preview";
import Timeline from "@/editor/Timeline";
import { EMPTY_EDIT, loadSettings, mergeSettings, saveSettings, useDerived, useHistory, type EditState, type Settings } from "@/editor/state";

type Tab = "cortes" | "texto" | "legendas" | "apoios" | "estilo";
type Upload = { phase: "idle" | "enviando" | "analisando" | "erro"; progress: number; fileName: string; error?: string };

const SESSION_KEY = "corteflow:sessao:v3";
const FORMAT_LABEL: Record<string, string> = { "9:16": "9:16", "9:16-blur": "9:16 com fundo", "4:5": "4:5", "1:1": "1:1", original: "Original" };

function subtractRange(ranges: Range[], cut: Range): Range[] {
  const out: Range[] = [];
  for (const r of ranges) {
    if (r.end <= cut.start || r.start >= cut.end) { out.push(r); continue; }
    if (r.start < cut.start) out.push({ start: r.start, end: cut.start });
    if (r.end > cut.end) out.push({ start: cut.end, end: r.end });
  }
  return out.filter((r) => r.end - r.start > 0.03);
}

export default function Home() {
  const [config, setConfig] = useState<ServerConfig | null>(null);
  const [project, setProject] = useState<ProjectInfo | null>(null);
  const [transcript, setTranscript] = useState<TranscriptState>({ status: "pendente", provider: null, words: [] });
  const [videoSrc, setVideoSrc] = useState<string | null>(null);
  const [upload, setUpload] = useState<Upload>({ phase: "idle", progress: 0, fileName: "" });
  const [settings, setSettingsState] = useState<Settings>(() => loadSettings());
  const [hookText, setHookText] = useState("");
  const [tab, setTab] = useState<Tab>("cortes");
  const [currentTime, setCurrentTime] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [showEdit, setShowEdit] = useState(true);
  const [selection, setSelection] = useState<Range | null>(null);
  const [exportOpen, setExportOpen] = useState(false);
  const [shortcutsOpen, setShortcutsOpen] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [toast, setToast] = useState("");
  const [framing, setFraming] = useState<FramingKey[]>([]);
  const [framingStatus, setFramingStatus] = useState<FramingStatus>({ state: "parado", progress: 0 });
  const [media, setMedia] = useState<MediaInfo[]>([]);
  const history = useHistory(EMPTY_EDIT);
  const { edit, commit } = history;
  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInput = useRef<HTMLInputElement>(null);
  const needsProxy = useRef(false);

  const derived = useDerived(project, transcript.words, edit, settings);
  const { words, suggestions, isApplied, cuts, keep, zooms, outZooms, inserts, outInserts, outputDuration } = derived;

  const setSettings = useCallback((update: (s: Settings) => Settings) => {
    setSettingsState((s) => {
      const next = update(s);
      saveSettings(next);
      return next;
    });
  }, []);

  const notify = useCallback((message: string) => setToast(message), []);
  useEffect(() => {
    if (!toast) return;
    const t = window.setTimeout(() => setToast(""), 3200);
    return () => window.clearTimeout(t);
  }, [toast]);

  // Configuração do servidor + retomar a última sessão
  useEffect(() => {
    getConfig().then(setConfig).catch(() => setConfig({ transcription: null, maxUploadMb: 2048 }));
    try {
      const raw = localStorage.getItem(SESSION_KEY);
      if (!raw) return;
      const saved = JSON.parse(raw) as { projectId: string; edit: EditState; hookText?: string; framing?: FramingKey[] };
      getProject(saved.projectId)
        .then((data) => {
          setProject(data.project);
          setTranscript(data.transcript);
          setVideoSrc(`/api/projects/${data.project.id}/preview.mp4`);
          history.reset({ ...EMPTY_EDIT, ...saved.edit });
          setHookText(saved.hookText ?? "");
          setMedia(data.project.media ?? []);
          if (saved.framing?.length) { setFraming(saved.framing); setFramingStatus({ state: "pronto", progress: 1 }); }
          notify("Projeto anterior reaberto.");
        })
        .catch(() => localStorage.removeItem(SESSION_KEY));
    } catch { /* sem sessão */ }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!project) return;
    try { localStorage.setItem(SESSION_KEY, JSON.stringify({ projectId: project.id, edit, hookText, framing })); } catch { /* ok */ }
  }, [project, edit, hookText, framing]);

  // Enquadramento: procura o rosto no navegador assim que o vídeo chega
  const framingRun = useRef(0);
  const runFraming = useCallback(async () => {
    if (!project || !videoSrc) return;
    const run = ++framingRun.current;
    setFramingStatus({ state: "rodando", progress: 0 });
    try {
      const result = await trackFace(videoSrc, project.duration, (p) => { if (run === framingRun.current) setFramingStatus({ state: "rodando", progress: p }); });
      if (run !== framingRun.current) return;
      setFraming(result.keys);
      setFramingStatus(result.keys.length
        ? { state: "pronto", progress: 1, message: `Visto em ${Math.round((result.found / Math.max(1, result.samples)) * 100)}% do vídeo.` }
        : { state: "sem-rosto", progress: 1 });
    } catch (error) {
      console.warn("[CorteFlow] enquadramento falhou", error);
      if (run === framingRun.current) setFramingStatus({ state: "erro", progress: 0 });
    }
  }, [project, videoSrc]);
  useEffect(() => {
    if (project && videoSrc && settings.faceFraming && framingStatus.state === "parado") void runFraming();
  }, [project, videoSrc, settings.faceFraming, framingStatus.state, runFraming]);

  const handleUploadMedia = useCallback(async (file: File) => {
    if (!project) return null;
    try {
      const info = await uploadMedia(project.id, file);
      setMedia((m) => [...m, info]);
      return info;
    } catch (error) {
      notify(error instanceof Error ? error.message : "Não consegui enviar o arquivo.");
      return null;
    }
  }, [project, notify]);

  // Acompanha a transcrição enquanto ela roda no servidor
  useEffect(() => {
    if (!project || transcript.status !== "pendente") return;
    const t = window.setTimeout(async () => {
      try {
        const next = await getTranscript(project.id);
        setTranscript(next);
        if (next.status === "ok") notify(`Transcrição pronta: ${next.words.length} palavras.`);
      } catch {
        setTranscript((s) => ({ ...s }));
      }
    }, 2000);
    return () => window.clearTimeout(t);
  }, [project, transcript]);

  // Avisa antes de fechar a aba no meio de uma edição
  useEffect(() => {
    if (!project) return;
    const handler = (e: BeforeUnloadEvent) => { if (history.canUndo) e.preventDefault(); };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [project, history.canUndo]);

  const handleFile = useCallback(async (file?: File | null) => {
    if (!file) return;
    if (!file.type.startsWith("video/") && !/\.(mp4|mov|m4v|webm|mkv|avi)$/i.test(file.name)) {
      notify("Esse arquivo não é um vídeo.");
      return;
    }
    if (config && file.size > config.maxUploadMb * 1024 * 1024) {
      notify(`O vídeo passa do limite de ${config.maxUploadMb} MB.`);
      return;
    }
    videoRef.current?.pause();
    setPlaying(false);
    setProject(null);
    setSelection(null);
    setCurrentTime(0);
    history.reset(EMPTY_EDIT);
    setHookText("");
    setFraming([]);
    framingRun.current++;
    setFramingStatus({ state: "parado", progress: 0 });
    setMedia([]);
    needsProxy.current = false;
    if (videoSrc?.startsWith("blob:")) URL.revokeObjectURL(videoSrc);
    setVideoSrc(URL.createObjectURL(file));
    setTranscript({ status: "pendente", provider: null, words: [] });
    setUpload({ phase: "enviando", progress: 0, fileName: file.name });
    try {
      const data = await uploadVideo(file, (p) => setUpload((u) => ({ ...u, progress: p, phase: p >= 1 ? "analisando" : "enviando" })));
      setProject(data.project);
      setTranscript(data.transcript);
      setUpload({ phase: "idle", progress: 1, fileName: file.name });
      setTab("cortes");
      if (needsProxy.current) setVideoSrc(`/api/projects/${data.project.id}/preview.mp4`);
    } catch (error) {
      setUpload({ phase: "erro", progress: 0, fileName: file.name, error: error instanceof Error ? error.message : "Falha no envio." });
    }
  }, [config, history, notify, videoSrc]);

  const seek = useCallback((t: number) => {
    const video = videoRef.current;
    const clamped = Math.max(0, Math.min(project?.duration ?? t, t));
    if (video) video.currentTime = clamped;
    setCurrentTime(clamped);
  }, [project]);

  // começa o projeto no primeiro trecho que fica no vídeo
  const startedProject = useRef<string | null>(null);
  useEffect(() => {
    if (!project || startedProject.current === project.id || !keep.length) return;
    startedProject.current = project.id;
    seek(keep[0].start);
  }, [project, keep, seek]);

  // ---------------------------------------------------------------------------
  // Reprodução: pula os trechos cortados em tempo real
  // ---------------------------------------------------------------------------
  const cutsRef = useRef(cuts);
  cutsRef.current = cuts;
  const showEditRef = useRef(showEdit);
  showEditRef.current = showEdit;

  useEffect(() => {
    if (!playing) return;
    let frame = 0;
    const tick = () => {
      const video = videoRef.current;
      if (video) {
        const t = video.currentTime;
        if (showEditRef.current) {
          const cut = inRanges(t, cutsRef.current);
          if (cut) {
            if (cut.end >= video.duration - 0.05) {
              video.pause();
              setPlaying(false);
            } else video.currentTime = cut.end + 0.001;
          }
        }
        setCurrentTime(video.currentTime);
      }
      frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [playing]);

  const togglePlay = useCallback(async () => {
    const video = videoRef.current;
    if (!video) return;
    if (!video.paused) {
      video.pause();
      setPlaying(false);
      return;
    }
    if (video.ended || video.currentTime >= (project?.duration ?? video.duration) - 0.1) video.currentTime = keep[0]?.start ?? 0;
    try {
      await video.play();
      setPlaying(true);
    } catch {
      notify("O navegador bloqueou a reprodução. Clique de novo.");
    }
  }, [keep, notify, project]);

  const focusRange = useCallback((r: Range) => {
    setSelection({ start: r.start, end: r.end });
    seek(Math.max(0, r.start - 1.2));
  }, [seek]);

  // ---------------------------------------------------------------------------
  // Ações de edição
  // ---------------------------------------------------------------------------
  const restoreRange = useCallback((r: Range) => {
    commit((s) => ({
      ...s,
      manualCuts: subtractRange(s.manualCuts, r),
      wordCuts: s.wordCuts.filter((i) => {
        const w = words[i];
        return !w || w.end <= r.start || w.start >= r.end;
      }),
      applied: {
        ...s.applied,
        ...Object.fromEntries(suggestions.filter((x) => x.start < r.end && x.end > r.start && isApplied(x)).map((x) => [x.id, false])),
      },
    }));
  }, [commit, words, suggestions, isApplied]);

  const cutSelection = useCallback(() => {
    if (!selection || selection.end - selection.start < 0.05) return notify("Arraste na linha do tempo para marcar um trecho.");
    commit((s) => ({ ...s, manualCuts: [...s.manualCuts, selection] }));
    seek(selection.end);
    setSelection(null);
    notify(`Cortado: ${(selection.end - selection.start).toFixed(1)}s.`);
  }, [selection, commit, notify, seek]);

  const zoomSelection = useCallback(() => {
    if (!selection || selection.end - selection.start < 0.2) return notify("Marque um trecho de pelo menos 0,2s para dar zoom.");
    const scale = Math.max(1.18, settings.zoomScale + 0.06);
    commit((s) => ({ ...s, zooms: [...s.zooms.filter((z) => z.end <= selection.start || z.start >= selection.end), { ...selection, scale }] }));
    setSelection(null);
    notify(`Zoom de ${scale.toFixed(2)}× aplicado.`);
  }, [selection, settings.zoomScale, commit, notify]);

  const toggleSuggestion = useCallback((s: Suggestion, value: boolean) => {
    commit((st) => ({ ...st, applied: { ...st.applied, [s.id]: value } }));
  }, [commit]);

  const buildRequest = useCallback((): RenderRequest => {
    const flags = emphasisFlags(words);
    return {
      cuts,
      zooms,
      format: settings.format,
      words: transcript.status === "ok" ? words.map((w, i) => ({ text: w.text, start: w.start, end: w.end, emph: flags[i] })) : [],
      captions: { ...settings.captions, enabled: settings.captions.enabled && transcript.status === "ok" },
      hook: settings.hookEnabled && hookText.trim() ? { text: hookText.trim(), duration: settings.hookDuration } : null,
      inserts: inserts.map(({ id, kind, start, end, text, mediaId }) => ({ id, kind, start, end, text, mediaId: mediaId ?? null })),
      framing: settings.faceFraming ? framing : [],
      card: settings.card,
      audio: { ...settings.audio, musicId: edit.musicId },
      quality: settings.quality,
    };
  }, [cuts, zooms, settings, transcript.status, words, hookText, inserts, framing, edit.musicId]);

  const setInserts = useCallback((next: Insert[]) => commit((s) => ({ ...s, inserts: next })), [commit]);
  const addInsertAtPlayhead = useCallback(() => {
    const outStart = outputTimeAt(currentTime, cuts, keep);
    const end = mapToSource(Math.min(outputDuration, outStart + 2), keep);
    const start = mapToSource(outStart, keep);
    const spoken = words.filter((w) => w.start >= start - 0.05 && w.end <= end + 0.3 && !inRanges((w.start + w.end) / 2, cuts)).map((w) => w.text).join(" ");
    const next: Insert = { id: `apoio-${Date.now()}`, kind: "card", start, end: Math.max(end, start + 1), text: spoken || "Escreva a frase do card", mediaId: null };
    setInserts([...inserts.filter((i) => i.end <= start || i.start >= next.end), next].sort((a, b) => a.start - b.start));
    setTab("apoios");
  }, [currentTime, cuts, keep, outputDuration, words, inserts, setInserts]);

  const exportPattern = useCallback(() => {
    const blob = new Blob([JSON.stringify({ corteflow: "padrao", versao: 3, ...settings }, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "padrao-corteflow.json";
    a.click();
    URL.revokeObjectURL(a.href);
  }, [settings]);
  const importPattern = useCallback(async (file: File) => {
    try {
      const data = JSON.parse(await file.text());
      if (data?.corteflow !== "padrao") throw new Error();
      setSettings(() => mergeSettings(data));
      notify("Padrão de edição importado.");
    } catch {
      notify("Esse arquivo não é um padrão do CorteFlow.");
    }
  }, [setSettings, notify]);

  // ---------------------------------------------------------------------------
  // Atalhos de teclado
  // ---------------------------------------------------------------------------
  const markIn = useRef<number | null>(null);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (target.closest("input, textarea, select, [contenteditable]")) return;
      if (!project) return;
      const mod = e.ctrlKey || e.metaKey;
      if (mod && e.key.toLowerCase() === "z") { e.preventDefault(); e.shiftKey ? history.redo() : history.undo(); return; }
      if (mod && e.key.toLowerCase() === "y") { e.preventDefault(); history.redo(); return; }
      if (mod) return;
      switch (e.key) {
        case " ": e.preventDefault(); void togglePlay(); break;
        case "ArrowLeft": e.preventDefault(); seek(currentTime - (e.shiftKey ? 5 : 0.5)); break;
        case "ArrowRight": e.preventDefault(); seek(currentTime + (e.shiftKey ? 5 : 0.5)); break;
        case "i": case "I":
          markIn.current = currentTime;
          setSelection({ start: currentTime, end: Math.max(currentTime + 0.05, selection?.end ?? currentTime + 0.05) });
          break;
        case "o": case "O": {
          const start = markIn.current ?? selection?.start ?? Math.max(0, currentTime - 1);
          setSelection({ start: Math.min(start, currentTime), end: Math.max(start, currentTime) });
          break;
        }
        case "x": case "X": case "Delete": case "Backspace": e.preventDefault(); cutSelection(); break;
        case "z": case "Z": zoomSelection(); break;
        case "r": case "R": if (selection) { restoreRange(selection); setSelection(null); } break;
        case "e": case "E": setShowEdit((v) => !v); break;
        case "Escape": setSelection(null); markIn.current = null; break;
        case "Home": seek(0); break;
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [project, history, togglePlay, seek, currentTime, selection, cutSelection, zoomSelection, restoreRange]);

  // ---------------------------------------------------------------------------
  const pending = useMemo(() => suggestions.filter((s) => !isApplied(s)), [suggestions, isApplied]);
  const outTime = outputTimeAt(currentTime, cuts, keep);
  const busyUpload = upload.phase === "enviando" || upload.phase === "analisando";
  const hasEditor = Boolean(project || busyUpload);
  const appliedCount = cuts.length;

  return (
    <div
      className={`app ${dragging ? "dragging" : ""}`}
      onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
      onDragLeave={(e) => { if (e.currentTarget === e.target) setDragging(false); }}
      onDrop={(e) => { e.preventDefault(); setDragging(false); void handleFile(e.dataTransfer.files?.[0]); }}
    >
      <header className="topbar">
        <div className="brand">
          <span className="brand-mark"><Scissors size={15} /></span>
          <b>CorteFlow</b>
        </div>
        {project && (
          <div className="project-meta">
            <span className="project-name" title={project.name}>{project.name}</span>
            <span className="pill">{project.width}×{project.height}</span>
            <TranscriptPill transcript={transcript} />
          </div>
        )}
        <div className="top-actions">
          {project && (
            <>
              <button className="icon-btn" onClick={history.undo} disabled={!history.canUndo} title="Desfazer (Ctrl+Z)"><Undo2 size={16} /></button>
              <button className="icon-btn" onClick={history.redo} disabled={!history.canRedo} title="Refazer (Ctrl+Shift+Z)"><Redo2 size={16} /></button>
              <span className="divider" />
            </>
          )}
          <button className="btn ghost" onClick={() => setShortcutsOpen(true)}><Keyboard size={15} /> Atalhos</button>
          <button className="btn" onClick={() => fileInput.current?.click()}><Upload size={15} /> Novo vídeo</button>
          <button className="btn primary" disabled={!project} onClick={() => setExportOpen(true)}><Download size={15} /> Exportar</button>
        </div>
      </header>

      {!hasEditor && (
        <Dropzone onPick={() => fileInput.current?.click()} config={config} upload={upload} />
      )}

      {hasEditor && (
        <main className="editor">
          <section className="stage">
            <div className="stage-view">
              {videoSrc && project ? (
                <Preview
                  videoRef={videoRef}
                  src={videoSrc}
                  project={project}
                  format={settings.format}
                  currentTime={currentTime}
                  playing={playing}
                  showEdit={showEdit}
                  words={transcript.status === "ok" ? words : []}
                  cuts={cuts}
                  keep={keep}
                  outZooms={settings.autoZoom || edit.zooms.length ? outZooms : []}
                  outInserts={outInserts}
                  framing={settings.faceFraming ? framing : []}
                  media={media}
                  captions={settings.captions}
                  card={settings.card}
                  hook={settings.hookEnabled && hookText.trim() ? { text: hookText, duration: settings.hookDuration } : null}
                  onVideoError={() => {
                    if (project && !videoSrc.includes("preview.mp4")) {
                      setVideoSrc(`/api/projects/${project.id}/preview.mp4`);
                      notify("Seu navegador não abre esse formato. Gerando uma prévia compatível…");
                    } else if (!project) needsProxy.current = true;
                  }}
                  onTime={(t) => { if (!playing) setCurrentTime(t); }}
                  onEnded={() => setPlaying(false)}
                />
              ) : (
                <div className="stage-loading">
                  <Loader2 className="spin" size={26} />
                  <b>{upload.phase === "enviando" ? `Enviando ${Math.round(upload.progress * 100)}%` : "Lendo o áudio e montando a linha do tempo…"}</b>
                  <div className="bar"><span style={{ width: `${Math.max(4, upload.progress * 100)}%` }} /></div>
                  <small>{upload.fileName}</small>
                </div>
              )}
            </div>

            {project && (
              <div className="transport">
                <button className="play" onClick={() => void togglePlay()} aria-label={playing ? "Pausar" : "Tocar"}>
                  {playing ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" />}
                </button>
                <button className="icon-btn" onClick={() => seek(keep[0]?.start ?? 0)} title="Voltar ao início"><SkipBack size={15} /></button>
                <div className="timecode">
                  <b>{formatTime(showEdit ? outTime : currentTime, true)}</b>
                  <span>/ {formatTime(showEdit ? outputDuration : project.duration, true)}</span>
                </div>
                <div className="spacer" />
                <div className="view-toggle">
                  <button className={showEdit ? "active" : ""} onClick={() => setShowEdit(true)}>Com edição</button>
                  <button className={!showEdit ? "active" : ""} onClick={() => setShowEdit(false)}>Original</button>
                </div>
              </div>
            )}

            {selection && project && (
              <div className="selection-bar">
                <span><b>{formatTime(selection.start, true)} – {formatTime(selection.end, true)}</b> · {(selection.end - selection.start).toFixed(1)}s</span>
                <button className="btn small danger" onClick={cutSelection}><Scissors size={13} /> Cortar <kbd>X</kbd></button>
                <button className="btn small" onClick={() => { restoreRange(selection); setSelection(null); }}><Undo2 size={13} /> Restaurar <kbd>R</kbd></button>
                <button className="btn small" onClick={zoomSelection}><ZoomIn size={13} /> Zoom <kbd>Z</kbd></button>
                <button className="icon-btn" onClick={() => setSelection(null)} aria-label="Limpar seleção"><X size={14} /></button>
              </div>
            )}

            {project && (
              <Timeline
                project={project}
                cuts={cuts}
                pending={pending}
                zooms={zooms}
                inserts={inserts}
                currentTime={currentTime}
                playing={playing}
                selection={selection}
                onSeek={seek}
                onSelect={setSelection}
              />
            )}
          </section>

          <aside className="side">
            <nav className="tabs">
              <button className={tab === "cortes" ? "active" : ""} onClick={() => setTab("cortes")}><Scissors size={15} /> Cortes <span>{appliedCount}</span></button>
              <button className={tab === "texto" ? "active" : ""} onClick={() => setTab("texto")}><Type size={15} /> Texto</button>
              <button className={tab === "legendas" ? "active" : ""} onClick={() => setTab("legendas")}><Captions size={15} /> Legendas</button>
              <button className={tab === "apoios" ? "active" : ""} onClick={() => setTab("apoios")}><Layers size={15} /> Apoios <span className="soft">{outInserts.length}</span></button>
              <button className={tab === "estilo" ? "active" : ""} onClick={() => setTab("estilo")}><Palette size={15} /> Estilo</button>
            </nav>
            {!project && <div className="panel-body center"><Loader2 className="spin" size={20} /><p className="note">Analisando o vídeo…</p></div>}
            {project && tab === "cortes" && (
              <CutsPanel
                project={project}
                suggestions={suggestions}
                isApplied={isApplied}
                edit={edit}
                settings={settings}
                outputDuration={outputDuration}
                transcript={transcript}
                setSettings={setSettings}
                toggleSuggestion={toggleSuggestion}
                removeManualCut={(r) => commit((s) => ({ ...s, manualCuts: s.manualCuts.filter((m) => m !== r) }))}
                focusRange={focusRange}
              />
            )}
            {project && tab === "texto" && (
              <TextPanel
                transcript={transcript}
                words={words}
                cuts={cuts}
                pending={pending}
                currentTime={currentTime}
                wordCuts={edit.wordCuts}
                onSeek={seek}
                onCutWords={(from, to) => commit((s) => ({ ...s, wordCuts: [...s.wordCuts, ...Array.from({ length: to - from + 1 }, (_, k) => from + k)] }))}
                onRestoreWords={(from, to) => restoreRange({ start: words[from].start, end: words[to].end })}
                onEditWord={(i, text) => { if (text !== words[i].text) commit((s) => ({ ...s, wordEdits: { ...s.wordEdits, [i]: text } })); }}
                onRetry={() => project && retryTranscript(project.id).then(setTranscript).catch(() => notify("Não consegui reiniciar a transcrição."))}
                transcriptionProvider={config?.transcription ?? null}
                emphasisFlags={emphasisFlags(words)}
                onToggleEmphasis={(from, to, value) => commit((s) => {
                  const next = { ...s.emphasis };
                  for (let i = from; i <= to; i++) next[i] = value;
                  return { ...s, emphasis: next };
                })}
              />
            )}
            {project && tab === "legendas" && (
              <CaptionsPanel settings={settings} setSettings={setSettings} hookText={hookText} setHookText={setHookText} transcriptReady={transcript.status === "ok"} />
            )}
            {project && tab === "apoios" && (
              <InsertsPanel
                inserts={inserts}
                outInserts={outInserts}
                outputDuration={outputDuration}
                transcriptReady={transcript.status === "ok"}
                customized={edit.inserts !== null}
                settings={settings}
                setSettings={setSettings}
                media={media}
                currentTime={currentTime}
                onChange={setInserts}
                onReset={() => commit((s) => ({ ...s, inserts: null }))}
                onAddAtPlayhead={addInsertAtPlayhead}
                onUpload={handleUploadMedia}
                focusRange={focusRange}
              />
            )}
            {project && tab === "estilo" && (
              <StylePanel
                settings={settings}
                setSettings={setSettings}
                manualZooms={edit.zooms}
                autoZoomCount={zooms.filter((z) => z.auto).length}
                removeZoom={(z: ZoomRange) => commit((s) => ({ ...s, zooms: s.zooms.filter((x) => x !== z) }))}
                focusRange={focusRange}
                framing={framingStatus}
                onRetryFraming={() => void runFraming()}
                media={media}
                musicId={edit.musicId}
                setMusic={(id) => commit((s) => ({ ...s, musicId: id }))}
                onUpload={handleUploadMedia}
                onExportPattern={exportPattern}
                onImportPattern={importPattern}
              />
            )}
          </aside>
        </main>
      )}

      {upload.phase === "erro" && (
        <div className="toast error">{upload.error} <button onClick={() => setUpload({ phase: "idle", progress: 0, fileName: "" })}><X size={14} /></button></div>
      )}

      {exportOpen && project && (
        <ExportDialog
          projectId={project.id}
          defaultName={project.name}
          buildRequest={buildRequest}
          summary={{ duration: outputDuration, cuts: cuts.length, zooms: zooms.length, inserts: outInserts.length, captions: settings.captions.enabled && transcript.status === "ok", format: FORMAT_LABEL[settings.format] }}
          quality={settings.quality}
          setQuality={(q) => setSettings((s) => ({ ...s, quality: q }))}
          onClose={() => setExportOpen(false)}
        />
      )}

      {shortcutsOpen && <Shortcuts onClose={() => setShortcutsOpen(false)} />}
      {dragging && <div className="drop-overlay"><Film size={34} /><b>Solte o vídeo para começar</b></div>}
      {toast && <div className="toast">{toast}</div>}
      <input ref={fileInput} type="file" accept="video/*,.mov,.mkv" hidden onChange={(e) => { void handleFile(e.target.files?.[0]); e.target.value = ""; }} />
    </div>
  );
}

function TranscriptPill({ transcript }: { transcript: TranscriptState }) {
  if (transcript.status === "pendente") return <span className="pill busy"><Loader2 className="spin" size={11} /> transcrevendo</span>;
  if (transcript.status === "ok") return <span className="pill ok">transcrição pronta</span>;
  if (transcript.status === "erro") return <span className="pill warn">transcrição falhou</span>;
  return <span className="pill">sem transcrição</span>;
}

function Dropzone({ onPick, config, upload }: { onPick: () => void; config: ServerConfig | null; upload: Upload }) {
  return (
    <main className="empty-state">
      <div className="empty-inner">
        <span className="eyebrow">Editor de Reels</span>
        <h1>Solte o vídeo bruto.<br /><em>Saia com o Reel cortado.</em></h1>
        <p>O CorteFlow tira as pausas, os “ahn”, as repetições e as frases que você regravou, coloca legenda palavra por palavra e exporta em 9:16 pronto para postar.</p>
        <button className="dropzone" onClick={onPick}>
          <Upload size={22} />
          <b>Arraste o vídeo aqui ou clique para escolher</b>
          <small>MP4, MOV ou WEBM · até {config?.maxUploadMb ?? 2048} MB</small>
        </button>
        {upload.phase === "erro" && <p className="error-text">{upload.error}</p>}
        <ol className="steps">
          <li><b>1</b><span>Importa o vídeo e a fala é analisada sozinha.</span></li>
          <li><b>2</b><span>Você revisa os cortes na linha do tempo ou direto no texto.</span></li>
          <li><b>3</b><span>Escolhe legenda e formato, e baixa o MP4.</span></li>
        </ol>
        {config && !config.transcription && (
          <p className="note warn-box">A transcrição está desligada neste servidor, então hoje só os cortes de pausa funcionam. Coloque <code>GROQ_API_KEY</code> ou <code>OPENAI_API_KEY</code> no <code>.env</code> para ligar legendas e detecção de repetições.</p>
        )}
      </div>
    </main>
  );
}

function Shortcuts({ onClose }: { onClose: () => void }) {
  const rows: Array<[string, string]> = [
    ["Espaço", "Tocar / pausar"],
    ["← →", "Voltar / avançar meio segundo (Shift: 5s)"],
    ["Arrastar na linha do tempo", "Selecionar um trecho"],
    ["I  /  O", "Marcar início / fim do trecho na agulha"],
    ["X  ou  Delete", "Cortar o trecho selecionado"],
    ["R", "Restaurar o trecho selecionado"],
    ["Z", "Dar zoom no trecho selecionado"],
    ["E", "Alternar prévia com edição / original"],
    ["Ctrl + Z", "Desfazer"],
    ["Ctrl + Shift + Z", "Refazer"],
    ["Ctrl + rolagem", "Aproximar a linha do tempo"],
  ];
  return (
    <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal">
        <header><h2>Atalhos</h2><button className="icon-btn" onClick={onClose}><X size={16} /></button></header>
        <dl className="shortcuts">
          {rows.map(([k, v]) => (<div key={k}><dt><kbd>{k}</kbd></dt><dd>{v}</dd></div>))}
        </dl>
      </div>
    </div>
  );
}
