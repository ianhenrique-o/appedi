import { useCallback, useMemo, useState } from "react";
import {
  DEFAULT_AUDIO, DEFAULT_CAPTION_STYLE, DEFAULT_CARD, DEFAULT_SILENCE, autoInserts, autoZooms, cleanCuts, detectSilences, detectSpeechIssues,
  insertsToOutput, keepSegments, refineSilences, totalLength, zoomsToOutput,
  type AudioOptions, type CaptionStyle, type CardStyle, type Insert, type ProjectInfo, type Range, type SilenceOptions, type Suggestion,
  type SuggestionKind, type VideoFormat, type Word, type ZoomRange,
} from "@shared/editor";

// ---------------------------------------------------------------------------
// Edição (com desfazer/refazer)
// ---------------------------------------------------------------------------

export type EditState = {
  manualCuts: Range[];
  wordCuts: number[];
  applied: Record<string, boolean>;
  zooms: ZoomRange[];
  wordEdits: Record<number, string>;
  /** true/false força o destaque da palavra na legenda */
  emphasis: Record<number, boolean>;
  /** null = usa as sugestões automáticas de apoio */
  inserts: Insert[] | null;
  musicId: string | null;
};

export const EMPTY_EDIT: EditState = { manualCuts: [], wordCuts: [], applied: {}, zooms: [], wordEdits: {}, emphasis: {}, inserts: null, musicId: null };

export function useHistory(initial: EditState) {
  const [history, setHistory] = useState({ past: [] as EditState[], present: initial, future: [] as EditState[] });
  const commit = useCallback((update: (s: EditState) => EditState) => {
    setHistory((h) => {
      const next = update(h.present);
      if (next === h.present) return h;
      return { past: [...h.past.slice(-80), h.present], present: next, future: [] };
    });
  }, []);
  const undo = useCallback(() => setHistory((h) => (h.past.length ? { past: h.past.slice(0, -1), present: h.past[h.past.length - 1], future: [h.present, ...h.future] } : h)), []);
  const redo = useCallback(() => setHistory((h) => (h.future.length ? { past: [...h.past, h.present], present: h.future[0], future: h.future.slice(1) } : h)), []);
  const reset = useCallback((s: EditState) => setHistory({ past: [], present: s, future: [] }), []);
  return { edit: history.present, commit, undo, redo, reset, canUndo: history.past.length > 0, canRedo: history.future.length > 0 };
}

// ---------------------------------------------------------------------------
// Padrão de edição (salvo no navegador e exportável em arquivo)
// ---------------------------------------------------------------------------

export type Settings = {
  silence: SilenceOptions;
  autoCutKinds: Record<SuggestionKind, boolean>;
  autoZoom: boolean;
  zoomScale: number;
  faceFraming: boolean;
  autoInserts: boolean;
  format: VideoFormat;
  captions: CaptionStyle;
  card: CardStyle;
  hookEnabled: boolean;
  hookDuration: number;
  audio: Omit<AudioOptions, "musicId">;
  quality: "rapida" | "alta";
};

export const DEFAULT_SETTINGS: Settings = {
  silence: DEFAULT_SILENCE,
  autoCutKinds: { silence: true, filler: true, repeat: true, retake: true, backstage: false },
  autoZoom: true,
  zoomScale: 1.08,
  faceFraming: true,
  autoInserts: true,
  format: "9:16",
  captions: DEFAULT_CAPTION_STYLE,
  card: DEFAULT_CARD,
  hookEnabled: false,
  hookDuration: 3,
  audio: { normalize: DEFAULT_AUDIO.normalize, cleanVoice: DEFAULT_AUDIO.cleanVoice, musicVolume: DEFAULT_AUDIO.musicVolume },
  quality: "rapida",
};

const SETTINGS_KEY = "corteflow:padrao:v3";

export function mergeSettings(saved: Partial<Settings>): Settings {
  return {
    ...DEFAULT_SETTINGS,
    ...saved,
    silence: { ...DEFAULT_SETTINGS.silence, ...saved.silence },
    autoCutKinds: { ...DEFAULT_SETTINGS.autoCutKinds, ...saved.autoCutKinds },
    captions: { ...DEFAULT_SETTINGS.captions, ...saved.captions },
    card: { ...DEFAULT_SETTINGS.card, ...saved.card },
    audio: { ...DEFAULT_SETTINGS.audio, ...saved.audio },
    zoomScale: Math.min(1.15, Math.max(1.02, saved.zoomScale ?? DEFAULT_SETTINGS.zoomScale)),
  };
}

export function loadSettings(): Settings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    return raw ? mergeSettings(JSON.parse(raw)) : DEFAULT_SETTINGS;
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: Settings) {
  try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings)); } catch { /* armazenamento bloqueado */ }
}

// ---------------------------------------------------------------------------
// Tudo o que é calculado a partir do vídeo + edição + padrão
// ---------------------------------------------------------------------------

export function wordRuns(indices: number[], words: Word[]): Range[] {
  const sorted = [...new Set(indices)].filter((i) => words[i]).sort((a, b) => a - b);
  const out: Range[] = [];
  let runStart = -1;
  sorted.forEach((idx, k) => {
    if (runStart < 0) runStart = idx;
    const next = sorted[k + 1];
    if (next !== idx + 1) {
      const first = words[runStart];
      const last = words[idx];
      const after = words[idx + 1];
      // vai até o começo da próxima palavra quando o respiro é curto
      const end = after && after.start - last.end < 0.25 ? after.start : last.end;
      out.push({ start: first.start, end });
      runStart = -1;
    }
  });
  return out;
}

export function useDerived(project: ProjectInfo | null, rawWords: Word[], edit: EditState, settings: Settings) {
  const words = useMemo(
    () => rawWords.map((w, i) => {
      const text = edit.wordEdits[i];
      const emph = edit.emphasis[i];
      return text !== undefined || emph !== undefined ? { ...w, ...(text !== undefined ? { text } : {}), ...(emph !== undefined ? { emph } : {}) } : w;
    }),
    [rawWords, edit.wordEdits, edit.emphasis],
  );

  const suggestions = useMemo<Suggestion[]>(() => {
    if (!project) return [];
    const silences = project.envelope.length ? refineSilences(detectSilences(project.envelope, project.envelopeRate, project.duration, settings.silence), words) : [];
    return [...silences, ...detectSpeechIssues(words)].sort((a, b) => a.start - b.start);
  }, [project, words, settings.silence]);

  const isApplied = useCallback(
    (s: Suggestion) => edit.applied[s.id] ?? settings.autoCutKinds[s.kind],
    [edit.applied, settings.autoCutKinds],
  );

  const cuts = useMemo(() => {
    if (!project) return [];
    return cleanCuts([
      ...suggestions.filter(isApplied),
      ...edit.manualCuts,
      ...wordRuns(edit.wordCuts, words),
    ], words).map((r) => ({ start: Math.max(0, r.start), end: Math.min(project.duration, r.end) }));
  }, [project, suggestions, isApplied, edit.manualCuts, edit.wordCuts, words]);

  const keep = useMemo(() => (project ? keepSegments(cuts, project.duration) : []), [project, cuts]);

  const zooms = useMemo<ZoomRange[]>(() => {
    const auto = settings.autoZoom ? autoZooms(keep, words, settings.zoomScale) : [];
    const manual = edit.zooms;
    const filteredAuto = auto.filter((a) => !manual.some((m) => a.start < m.end && a.end > m.start));
    return [...filteredAuto, ...manual].sort((a, b) => a.start - b.start);
  }, [settings.autoZoom, settings.zoomScale, keep, words, edit.zooms]);

  const suggestedInserts = useMemo(() => (settings.autoInserts ? autoInserts(keep, words) : []), [settings.autoInserts, keep, words]);
  const inserts = edit.inserts ?? suggestedInserts;

  const outZooms = useMemo(() => zoomsToOutput(zooms, keep), [zooms, keep]);
  const outInserts = useMemo(() => insertsToOutput(inserts, keep), [inserts, keep]);
  const outputDuration = useMemo(() => totalLength(keep), [keep]);

  return { words, suggestions, isApplied, cuts, keep, zooms, outZooms, inserts, outInserts, suggestedInserts, outputDuration };
}

export type Derived = ReturnType<typeof useDerived>;
