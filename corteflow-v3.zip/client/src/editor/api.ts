import type { JobState, MediaInfo, ProjectInfo, RenderRequest, TranscriptState } from "@shared/editor";

export type ServerConfig = { transcription: string | null; maxUploadMb: number };
export type ProjectPayload = { project: ProjectInfo; transcript: TranscriptState };

async function json<T>(response: Response): Promise<T> {
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error((data as { error?: string }).error || `Erro ${response.status}`);
  return data as T;
}

export const getConfig = () => fetch("/api/config").then((r) => json<ServerConfig>(r));
export const getProject = (id: string) => fetch(`/api/projects/${id}`).then((r) => json<ProjectPayload>(r));
export const getTranscript = (id: string) => fetch(`/api/projects/${id}/transcript`).then((r) => json<TranscriptState>(r));
export const retryTranscript = (id: string) => fetch(`/api/projects/${id}/transcribe`, { method: "POST" }).then((r) => json<TranscriptState>(r));
export const getJob = (id: string) => fetch(`/api/jobs/${id}`).then((r) => json<JobState>(r));

export function startRender(projectId: string, body: RenderRequest) {
  return fetch(`/api/projects/${projectId}/render`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  }).then((r) => json<JobState>(r));
}

/** Envia o vídeo uma única vez, com progresso de upload. */
export function uploadVideo(file: File, onProgress: (fraction: number) => void) {
  return new Promise<ProjectPayload>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/api/projects");
    xhr.setRequestHeader("Content-Type", file.type || "application/octet-stream");
    xhr.setRequestHeader("X-File-Name", encodeURIComponent(file.name));
    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable) onProgress(event.loaded / event.total);
    };
    xhr.onload = () => {
      let data: unknown = {};
      try { data = JSON.parse(xhr.responseText); } catch { /* resposta vazia */ }
      if (xhr.status >= 200 && xhr.status < 300) resolve(data as ProjectPayload);
      else reject(new Error((data as { error?: string }).error || "Falha no envio do vídeo."));
    };
    xhr.onerror = () => reject(new Error("A conexão caiu durante o envio."));
    xhr.send(file);
  });
}

export function uploadMedia(projectId: string, file: File) {
  return fetch(`/api/projects/${projectId}/media`, {
    method: "POST",
    headers: { "Content-Type": file.type || "application/octet-stream", "X-File-Name": encodeURIComponent(file.name) },
    body: file,
  }).then((r) => json<MediaInfo>(r));
}
