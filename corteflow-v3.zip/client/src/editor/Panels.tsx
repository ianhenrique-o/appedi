import { useEffect, useMemo, useRef, useState } from "react";
import { AlertTriangle, Check, Download, Film, Highlighter, ImageIcon, Loader2, MicOff, Music, Plus, RefreshCw, RotateCcw, ScanFace, Scissors, Sparkles, Trash2, Type, Undo2, Upload, Wand2, ZoomIn } from "lucide-react";
import type { CaptionStyle, Insert, MediaInfo, ProjectInfo, Range, Suggestion, SuggestionKind, TranscriptState, VideoFormat, Word, ZoomRange } from "@shared/editor";
import { DEFAULT_CAPTION_STYLE, formatTime, inRanges, sentences } from "@shared/editor";
import { ColorField, Section, Segmented, Slider, Switch } from "./controls";
import { DEFAULT_SETTINGS, type EditState, type Settings } from "./state";

const KIND_LABEL: Record<SuggestionKind, string> = { silence: "Pausas", filler: "Vícios de fala", repeat: "Repetições", retake: "Regravações", backstage: "Bastidor" };
const KIND_HINT: Record<SuggestionKind, string> = {
  silence: "Silêncio entre frases, no começo e no fim.",
  filler: "“Ahn”, “hum”, “éé” soltos na fala.",
  repeat: "Palavra ou trecho dito duas vezes seguidas.",
  retake: "Frase que você recomeçou. Fica a última tentativa.",
  backstage: "“Corta”, “errei”, “vou de novo” e afins.",
};

// ---------------------------------------------------------------------------
// Cortes
// ---------------------------------------------------------------------------

export function CutsPanel(props: {
  project: ProjectInfo;
  suggestions: Suggestion[];
  isApplied: (s: Suggestion) => boolean;
  edit: EditState;
  settings: Settings;
  outputDuration: number;
  transcript: TranscriptState;
  setSettings: (u: (s: Settings) => Settings) => void;
  toggleSuggestion: (s: Suggestion, value: boolean) => void;
  removeManualCut: (r: Range) => void;
  focusRange: (r: Range) => void;
}) {
  const { project, suggestions, isApplied, settings, setSettings } = props;
  const [filter, setFilter] = useState<SuggestionKind | "todas">("todas");
  const counts = useMemo(() => {
    const c: Record<SuggestionKind, { total: number; on: number }> = { silence: { total: 0, on: 0 }, filler: { total: 0, on: 0 }, repeat: { total: 0, on: 0 }, retake: { total: 0, on: 0 }, backstage: { total: 0, on: 0 } };
    for (const s of suggestions) { c[s.kind].total++; if (isApplied(s)) c[s.kind].on++; }
    return c;
  }, [suggestions, isApplied]);
  const removed = project.duration - props.outputDuration;
  const list = suggestions.filter((s) => filter === "todas" || s.kind === filter);
  const speechReady = props.transcript.status === "ok";

  return (
    <div className="panel-body">
      <div className="summary-card">
        <div><small>Original</small><b>{formatTime(project.duration)}</b></div>
        <span className="summary-arrow">→</span>
        <div><small>Final</small><b className="accent">{formatTime(props.outputDuration)}</b></div>
        <div className="summary-saved"><small>Removido</small><b>−{removed.toFixed(1)}s</b><em>{project.duration ? Math.round((removed / project.duration) * 100) : 0}%</em></div>
      </div>

      <Section title="O que cortar sozinho">
        {(Object.keys(KIND_LABEL) as SuggestionKind[]).map((kind) => (
          <Switch
            key={kind}
            checked={settings.autoCutKinds[kind]}
            onChange={(v) => setSettings((s) => ({ ...s, autoCutKinds: { ...s.autoCutKinds, [kind]: v } }))}
            label={<>{KIND_LABEL[kind]} <span className="count">{counts[kind].on}/{counts[kind].total}</span></>}
            hint={kind !== "silence" && !speechReady ? "Precisa da transcrição." : KIND_HINT[kind]}
          />
        ))}
      </Section>

      <Section title="Sensibilidade das pausas">
        <Slider label="Pausa mínima para cortar" value={settings.silence.minPause} min={0.2} max={1.5} step={0.05} format={(v) => `${v.toFixed(2)}s`} onChange={(v) => setSettings((s) => ({ ...s, silence: { ...s.silence, minPause: v } }))} />
        <Slider label="Respiro antes e depois da fala" value={settings.silence.padding} min={0.02} max={0.35} step={0.01} format={(v) => `${Math.round(v * 1000)}ms`} onChange={(v) => setSettings((s) => ({ ...s, silence: { ...s.silence, padding: v } }))} />
        <Slider label="Volume considerado silêncio" value={settings.silence.thresholdDb} min={-60} max={-22} step={1} format={(v) => `${v} dB`} onChange={(v) => setSettings((s) => ({ ...s, silence: { ...s.silence, thresholdDb: v } }))} />
        <p className="note">Se está cortando pedaço de fala, abaixe o volume ou aumente o respiro. Se ficou pausa sobrando, faça o contrário.</p>
      </Section>

      <Section title="Revisar cortes" aside={<span className="count">{suggestions.filter(isApplied).length + props.edit.manualCuts.length} ativos</span>}>
        <div className="chips">
          {(["todas", "silence", "filler", "repeat", "retake", "backstage"] as const).map((k) => (
            <button key={k} className={filter === k ? "active" : ""} onClick={() => setFilter(k)}>
              {k === "todas" ? "Todas" : KIND_LABEL[k]}
              <span>{k === "todas" ? suggestions.length : counts[k].total}</span>
            </button>
          ))}
        </div>
        <div className="suggestion-list">
          {props.edit.manualCuts.map((r) => (
            <div key={`m-${r.start}`} className="suggestion on" onClick={() => props.focusRange(r)}>
              <span className="sg-icon manual"><Scissors size={13} /></span>
              <span className="sg-main"><b>Corte manual</b><small>{formatTime(r.start, true)} – {formatTime(r.end, true)} · {(r.end - r.start).toFixed(1)}s</small></span>
              <button className="sg-remove" title="Desfazer corte" onClick={(e) => { e.stopPropagation(); props.removeManualCut(r); }}><Trash2 size={14} /></button>
            </div>
          ))}
          {list.map((s) => {
            const on = isApplied(s);
            return (
              <div key={s.id} className={`suggestion ${on ? "on" : ""} ${s.kind === "backstage" && !on ? "review" : ""}`} onClick={() => props.focusRange(s)}>
                <span className={`sg-icon ${s.kind}`}>{s.kind === "silence" ? <MicOff size={13} /> : s.kind === "retake" || s.kind === "backstage" ? <RotateCcw size={13} /> : <Scissors size={13} />}</span>
                <span className="sg-main">
                  <b>{s.label}</b>
                  <small>{formatTime(s.start, true)} · {(s.end - s.start).toFixed(1)}s · {s.detail}</small>
                </span>
                <button className={`sg-check ${on ? "on" : ""}`} title={on ? "Manter esse trecho" : "Cortar esse trecho"} onClick={(e) => { e.stopPropagation(); props.toggleSuggestion(s, !on); }}>
                  {on ? <Check size={13} /> : null}
                </button>
              </div>
            );
          })}
          {!list.length && !props.edit.manualCuts.length && <p className="empty">Nada para revisar aqui.</p>}
        </div>
      </Section>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Texto (editar cortando palavras)
// ---------------------------------------------------------------------------

export function TextPanel(props: {
  transcript: TranscriptState;
  words: Word[];
  cuts: Range[];
  pending: Range[];
  currentTime: number;
  wordCuts: number[];
  onSeek: (t: number) => void;
  onCutWords: (from: number, to: number) => void;
  onRestoreWords: (from: number, to: number) => void;
  onEditWord: (index: number, text: string) => void;
  emphasisFlags: boolean[];
  onToggleEmphasis: (from: number, to: number, value: boolean) => void;
  onRetry: () => void;
  transcriptionProvider: string | null;
}) {
  const { transcript, words } = props;
  const [anchor, setAnchor] = useState<number | null>(null);
  const [focus, setFocus] = useState<number | null>(null);
  const [editing, setEditing] = useState<number | null>(null);
  const currentRef = useRef<HTMLSpanElement>(null);
  const boxRef = useRef<HTMLDivElement>(null);
  const paragraphs = useMemo(() => sentences(words, 1.2), [words]);
  const current = useMemo(() => {
    let found = -1;
    for (let i = 0; i < words.length; i++) {
      if (words[i].start <= props.currentTime + 0.02) found = i;
      else break;
    }
    return found;
  }, [words, props.currentTime]);

  useEffect(() => {
    const el = currentRef.current;
    const box = boxRef.current;
    if (!el || !box) return;
    const top = el.offsetTop - box.offsetTop;
    if (top < box.scrollTop + 40 || top > box.scrollTop + box.clientHeight - 60) box.scrollTo({ top: top - 120, behavior: "smooth" });
  }, [current]);

  if (transcript.status === "pendente") {
    return (
      <div className="panel-body center">
        <Loader2 className="spin" size={22} />
        <p><b>Transcrevendo sua fala…</b></p>
        <p className="note">Leva em média 20 a 60 segundos. Enquanto isso você já pode revisar as pausas.</p>
      </div>
    );
  }
  if (transcript.status !== "ok") {
    return (
      <div className="panel-body center">
        <AlertTriangle size={22} className="warn" />
        <p><b>{transcript.status === "erro" ? "A transcrição falhou" : "Transcrição desligada"}</b></p>
        <p className="note">{transcript.message}</p>
        {transcript.status === "erro" && <button className="btn" onClick={props.onRetry}><RefreshCw size={14} /> Tentar de novo</button>}
        {!props.transcriptionProvider && (
          <div className="howto">
            <p>Para ligar legendas automáticas, edição pelo texto e detecção de repetições, coloque uma destas chaves no arquivo <code>.env</code> do servidor e reinicie:</p>
            <pre>GROQ_API_KEY=...   (mais barato e rápido)
OPENAI_API_KEY=... (Whisper da OpenAI)</pre>
          </div>
        )}
      </div>
    );
  }

  const selFrom = anchor !== null && focus !== null ? Math.min(anchor, focus) : anchor;
  const selTo = anchor !== null && focus !== null ? Math.max(anchor, focus) : anchor;
  const hasSel = selFrom !== null && selTo !== null;
  const selectionCut = hasSel && Array.from({ length: selTo! - selFrom! + 1 }, (_, k) => selFrom! + k).every((i) => isCut(i));

  function isCut(i: number) {
    const w = words[i];
    return Boolean(inRanges((w.start + w.end) / 2, props.cuts));
  }

  return (
    <div className="panel-body text-panel">
      <p className="note">Clique numa palavra para ir até ela. <b>Shift + clique</b> marca um trecho. <b>Dois cliques</b> corrige a palavra na legenda. Riscado sai do vídeo, sublinhado tracejado é sugestão esperando revisão na aba Cortes e palavra em amarelo ganha cor na legenda.</p>
      {hasSel && (
        <div className="word-actions">
          <span>{selTo! - selFrom! + 1} palavra{selTo !== selFrom ? "s" : ""}</span>
          {selectionCut ? (
            <button className="btn small" onClick={() => { props.onRestoreWords(selFrom!, selTo!); setAnchor(null); setFocus(null); }}><Undo2 size={13} /> Restaurar</button>
          ) : (
            <button className="btn small danger" onClick={() => { props.onCutWords(selFrom!, selTo!); setAnchor(null); setFocus(null); }}><Scissors size={13} /> Cortar</button>
          )}
          {(() => {
            const allEmph = Array.from({ length: selTo! - selFrom! + 1 }, (_, k) => selFrom! + k).every((i) => props.emphasisFlags[i]);
            return (
              <button className="btn small" title="Muda a cor dessa palavra na legenda" onClick={() => props.onToggleEmphasis(selFrom!, selTo!, !allEmph)}>
                <Highlighter size={13} /> {allEmph ? "Tirar destaque" : "Destacar"}
              </button>
            );
          })()}
          <button className="btn small ghost" onClick={() => { setAnchor(null); setFocus(null); }}>Limpar</button>
        </div>
      )}
      <div className="transcript" ref={boxRef}>
        {paragraphs.map((p, pi) => (
          <p key={pi}>
            <span className="ts" onClick={() => props.onSeek(words[p[0]].start)}>{formatTime(words[p[0]].start)}</span>
            {p.map((i) => {
              const w = words[i];
              const cut = isCut(i);
              const pend = !cut && Boolean(inRanges((w.start + w.end) / 2, props.pending));
              const selected = hasSel && i >= selFrom! && i <= selTo!;
              const cls = ["w", cut ? "cut" : "", pend ? "pend" : "", props.emphasisFlags[i] ? "emph" : "", selected ? "sel" : "", i === current ? "now" : ""].join(" ");
              if (editing === i) {
                return (
                  <input
                    key={i}
                    className="w-edit"
                    autoFocus
                    defaultValue={w.text}
                    size={Math.max(3, w.text.length + 1)}
                    onBlur={(e) => { props.onEditWord(i, e.target.value.trim() || w.text); setEditing(null); }}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") (e.target as HTMLInputElement).blur();
                      if (e.key === "Escape") setEditing(null);
                      e.stopPropagation();
                    }}
                  />
                );
              }
              return (
                <span
                  key={i}
                  ref={i === current ? currentRef : undefined}
                  className={cls}
                  onClick={(e) => {
                    if (e.shiftKey && anchor !== null) setFocus(i);
                    else { setAnchor(i); setFocus(null); props.onSeek(w.start); }
                  }}
                  onDoubleClick={() => setEditing(i)}
                >
                  {w.text}{" "}
                </span>
              );
            })}
          </p>
        ))}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Legendas
// ---------------------------------------------------------------------------

const PRESETS: Array<{ name: string; style: Partial<CaptionStyle> }> = [
  { name: "Editorial", style: { font: "montserrat", uppercase: false, maxWords: 5, textColor: "#FFFFFF", highlightColor: "#FFD43B", emphasis: "chave", box: false, size: 78 } },
  { name: "Impacto", style: { font: "anton", uppercase: true, maxWords: 3, textColor: "#FFFFFF", highlightColor: "#3DF58C", emphasis: "chave", box: false, size: 92 } },
  { name: "Karaokê", style: { font: "montserrat", uppercase: true, maxWords: 3, textColor: "#FFFFFF", highlightColor: "#FFD43B", emphasis: "falada", box: false, size: 82 } },
  { name: "Discreta", style: { font: "poppins", uppercase: false, maxWords: 6, textColor: "#FFFFFF", highlightColor: "#FFFFFF", emphasis: "nenhuma", box: false, size: 56 } },
];

export function CaptionsPanel(props: {
  settings: Settings;
  setSettings: (u: (s: Settings) => Settings) => void;
  hookText: string;
  setHookText: (v: string) => void;
  transcriptReady: boolean;
}) {
  const { settings, setSettings } = props;
  const c = settings.captions;
  const set = (patch: Partial<CaptionStyle>) => setSettings((s) => ({ ...s, captions: { ...s.captions, ...patch } }));
  return (
    <div className="panel-body">
      {!props.transcriptReady && <p className="note warn-box">As legendas usam a transcrição. Sem ela, o vídeo sai sem legenda.</p>}
      <Section title="Legendas automáticas" aside={<Switch checked={c.enabled} onChange={(v) => set({ enabled: v })} label="" />}>
        <div className="presets">
          {PRESETS.map((p) => {
            const st = { ...DEFAULT_CAPTION_STYLE, ...p.style };
            const active = st.font === c.font && st.box === c.box && st.uppercase === c.uppercase && st.emphasis === c.emphasis && st.maxWords === c.maxWords;
            return (
              <button key={p.name} className={`preset ${active ? "active" : ""}`} onClick={() => set({ ...p.style, enabled: true })}>
                <span className={`preset-sample f-${st.font}`} style={{ background: st.box ? st.boxColor : undefined, textTransform: st.uppercase ? "uppercase" : "none" }}>
                  três <i style={{ color: st.emphasis !== "nenhuma" ? st.highlightColor : st.textColor }}>sinais</i>
                </span>
                <small>{p.name}</small>
              </button>
            );
          })}
        </div>
      </Section>
      <Section title="Ajuste fino">
        <div className="field-label">Fonte</div>
        <Segmented value={c.font} onChange={(v) => set({ font: v })} options={[{ value: "montserrat", label: "Montserrat" }, { value: "anton", label: "Anton" }, { value: "poppins", label: "Poppins" }]} />
        <div className="field-label">Posição</div>
        <Segmented value={c.position} onChange={(v) => set({ position: v })} options={[{ value: "cima", label: "Em cima" }, { value: "meio", label: "No meio" }, { value: "baixo", label: "Embaixo" }]} />
        <Slider label="Tamanho" value={c.size} min={40} max={130} step={2} onChange={(v) => set({ size: v })} format={(v) => `${v}px`} />
        <Slider label="Palavras por bloco (máximo)" value={c.maxWords} min={1} max={7} step={1} onChange={(v) => set({ maxWords: v })} />
        <Switch checked={c.uppercase} onChange={(v) => set({ uppercase: v })} label="Tudo em maiúsculas" />
        <div className="field-label">Destaque de cor</div>
        <Segmented value={c.emphasis} onChange={(v) => set({ emphasis: v })} options={[{ value: "chave", label: "Palavras-chave" }, { value: "falada", label: "Palavra falada" }, { value: "nenhuma", label: "Nenhum" }]} />
        <p className="note">{c.emphasis === "chave" ? "Números, benefícios e palavras fortes ganham cor, uma por bloco. Para escolher à mão, use a aba Texto." : c.emphasis === "falada" ? "A cor acompanha a palavra que está sendo dita." : "Legenda toda numa cor só."}</p>
        <Switch checked={c.box} onChange={(v) => set({ box: v })} label="Caixa atrás do texto" />
        <div className="colors">
          <ColorField label="Texto" value={c.textColor} onChange={(v) => set({ textColor: v })} />
          {c.emphasis !== "nenhuma" && <ColorField label="Destaque" value={c.highlightColor} onChange={(v) => set({ highlightColor: v })} />}
          {c.box && <ColorField label="Caixa" value={c.boxColor} onChange={(v) => set({ boxColor: v })} />}
        </div>
      </Section>
      <Section title="Gancho na tela" aside={<Switch checked={settings.hookEnabled} onChange={(v) => setSettings((s) => ({ ...s, hookEnabled: v }))} label="" />}>
        <p className="note">Frase fixa no topo nos primeiros segundos, para quem assiste sem som.</p>
        <textarea
          className="input"
          rows={2}
          maxLength={160}
          placeholder="Ex.: 3 sinais de que seu filho precisa de ajuda na fala"
          value={props.hookText}
          onChange={(e) => { props.setHookText(e.target.value); if (!settings.hookEnabled && e.target.value) setSettings((s) => ({ ...s, hookEnabled: true })); }}
          onKeyDown={(e) => e.stopPropagation()}
        />
        <Slider label="Tempo na tela" value={settings.hookDuration} min={1} max={10} step={0.5} format={(v) => `${v}s`} onChange={(v) => setSettings((s) => ({ ...s, hookDuration: v }))} />
      </Section>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Formato, zoom e áudio
// ---------------------------------------------------------------------------

const FORMATS: Array<{ value: VideoFormat; title: string; hint: string; ratio: string }> = [
  { value: "9:16", title: "Reels 9:16", hint: "Preenche a tela toda", ratio: "9 / 16" },
  { value: "9:16-blur", title: "9:16 com fundo", hint: "Vídeo deitado sem cortar as bordas", ratio: "9 / 16" },
  { value: "4:5", title: "Feed 4:5", hint: "Post de feed vertical", ratio: "4 / 5" },
  { value: "1:1", title: "Quadrado", hint: "1080 × 1080", ratio: "1 / 1" },
  { value: "original", title: "Original", hint: "Mantém o enquadramento", ratio: "16 / 10" },
];

export type FramingStatus = { state: "parado" | "rodando" | "pronto" | "sem-rosto" | "erro"; progress: number; message?: string };

export function StylePanel(props: {
  settings: Settings;
  setSettings: (u: (s: Settings) => Settings) => void;
  manualZooms: ZoomRange[];
  autoZoomCount: number;
  removeZoom: (z: ZoomRange) => void;
  focusRange: (r: Range) => void;
  framing: FramingStatus;
  onRetryFraming: () => void;
  media: MediaInfo[];
  musicId: string | null;
  setMusic: (id: string | null) => void;
  onUpload: (file: File) => Promise<MediaInfo | null>;
  onExportPattern: () => void;
  onImportPattern: (file: File) => void;
}) {
  const { settings, setSettings } = props;
  const musicInput = useRef<HTMLInputElement>(null);
  const patternInput = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const music = props.media.find((m) => m.id === props.musicId);
  const crops = settings.format === "9:16" || settings.format === "4:5" || settings.format === "1:1";
  const setAudio = (patch: Partial<Settings["audio"]>) => setSettings((s) => ({ ...s, audio: { ...s.audio, ...patch } }));
  return (
    <div className="panel-body">
      <Section title="Formato do vídeo">
        <div className="formats">
          {FORMATS.map((f) => (
            <button key={f.value} className={`format ${settings.format === f.value ? "active" : ""}`} onClick={() => setSettings((s) => ({ ...s, format: f.value }))}>
              <span className={`format-shape ${f.value === "9:16-blur" ? "blur" : ""}`} style={{ aspectRatio: f.ratio }} />
              <b>{f.title}</b>
              <small>{f.hint}</small>
            </button>
          ))}
        </div>
      </Section>

      <Section title="Enquadramento">
        <Switch
          checked={settings.faceFraming}
          onChange={(v) => setSettings((s) => ({ ...s, faceFraming: v }))}
          label={<><ScanFace size={14} className="inline-icon" /> Seguir o rosto</>}
          hint={crops ? "O recorte vertical acompanha o rosto com calma, sem cortar testa nem queixo." : "Nesse formato não há recorte; o rosto só orienta o zoom."}
        />
        {settings.faceFraming && (
          <p className="note">
            {props.framing.state === "rodando" && <><Loader2 size={12} className="spin inline-icon" /> Procurando o rosto… {Math.round(props.framing.progress * 100)}%</>}
            {props.framing.state === "pronto" && <><Check size={12} className="inline-icon ok" /> Rosto encontrado. {props.framing.message}</>}
            {props.framing.state === "sem-rosto" && "Nenhum rosto encontrado. O recorte fica centralizado."}
            {props.framing.state === "erro" && <>Não consegui analisar o rosto. <button className="link" onClick={props.onRetryFraming}>Tentar de novo</button></>}
            {props.framing.state === "parado" && <button className="link" onClick={props.onRetryFraming}>Analisar o rosto agora</button>}
          </p>
        )}
      </Section>

      <Section title="Zoom">
        <Switch
          checked={settings.autoZoom}
          onChange={(v) => setSettings((s) => ({ ...s, autoZoom: v }))}
          label={<>Zoom editorial <span className="count">{props.autoZoomCount}</span></>}
          hint="Aproximação lenta na abertura, punch-in leve em números e palavras fortes, e enquadramento mais fechado na conclusão. Nunca em todos os cortes."
        />
        {settings.autoZoom && <Slider label="Intensidade" value={settings.zoomScale} min={1.03} max={1.15} step={0.01} format={(v) => `${v.toFixed(2)}×`} onChange={(v) => setSettings((s) => ({ ...s, zoomScale: v }))} />}
        <p className="note">Para dar zoom num trecho específico, selecione na linha do tempo e aperte <kbd>Z</kbd>.</p>
        {props.manualZooms.length > 0 && (
          <div className="suggestion-list">
            {props.manualZooms.map((z) => (
              <div key={`${z.start}`} className="suggestion on" onClick={() => props.focusRange(z)}>
                <span className="sg-icon zoom"><ZoomIn size={13} /></span>
                <span className="sg-main"><b>Zoom {z.scale.toFixed(2)}×</b><small>{formatTime(z.start, true)} – {formatTime(z.end, true)}</small></span>
                <button className="sg-remove" onClick={(e) => { e.stopPropagation(); props.removeZoom(z); }}><Trash2 size={14} /></button>
              </div>
            ))}
          </div>
        )}
      </Section>

      <Section title="Áudio">
        <Switch checked={settings.audio.cleanVoice} onChange={(v) => setAudio({ cleanVoice: v })} label="Limpar a voz" hint="Tira o ruído de fundo constante, deixa a voz mais clara e nivela os trechos." />
        <Switch checked={settings.audio.normalize} onChange={(v) => setAudio({ normalize: v })} label="Volume no padrão do Instagram" hint="−14 LUFS, sem estourar nem ficar baixo." />
        <div className="field-label"><Music size={12} className="inline-icon" /> Música de fundo</div>
        {music ? (
          <div className="media-row">
            <span className="sg-icon zoom"><Music size={13} /></span>
            <span className="sg-main"><b>{music.name}</b><small>abaixa sozinha quando você fala</small></span>
            <button className="sg-remove" onClick={() => props.setMusic(null)} title="Tirar música"><Trash2 size={14} /></button>
          </div>
        ) : (
          <button className="btn ghost-border" disabled={uploading} onClick={() => musicInput.current?.click()}>
            {uploading ? <Loader2 size={14} className="spin" /> : <Upload size={14} />} Escolher música (MP3, WAV, M4A)
          </button>
        )}
        {music && <Slider label="Volume da música" value={settings.audio.musicVolume} min={0.05} max={0.4} step={0.01} format={(v) => `${Math.round(v * 100)}%`} onChange={(v) => setAudio({ musicVolume: v })} />}
        <input ref={musicInput} type="file" accept="audio/*,.mp3,.wav,.m4a" hidden onChange={async (e) => {
          const file = e.target.files?.[0];
          e.target.value = "";
          if (!file) return;
          setUploading(true);
          const info = await props.onUpload(file);
          setUploading(false);
          if (info) props.setMusic(info.id);
        }} />
      </Section>

      <Section title="Meu padrão de edição">
        <p className="note"><Sparkles size={12} className="inline-icon" /> Legenda, cortes, zoom, enquadramento, apoios e áudio ficam salvos neste navegador e valem para o próximo vídeo. Para usar o mesmo padrão em outro computador, exporte o arquivo.</p>
        <div className="row-buttons">
          <button className="btn" onClick={props.onExportPattern}><Download size={14} /> Exportar padrão</button>
          <button className="btn" onClick={() => patternInput.current?.click()}><Upload size={14} /> Importar</button>
        </div>
        <button className="btn ghost" onClick={() => setSettings(() => DEFAULT_SETTINGS)}><Wand2 size={14} /> Voltar ao padrão de fábrica</button>
        <input ref={patternInput} type="file" accept="application/json,.json" hidden onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ""; if (f) props.onImportPattern(f); }} />
      </Section>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Apoios visuais (cards, imagens e B-roll)
// ---------------------------------------------------------------------------

export function InsertsPanel(props: {
  inserts: Insert[];
  outInserts: Array<Insert & { a: number; b: number }>;
  outputDuration: number;
  transcriptReady: boolean;
  customized: boolean;
  settings: Settings;
  setSettings: (u: (s: Settings) => Settings) => void;
  media: MediaInfo[];
  currentTime: number;
  onChange: (next: Insert[]) => void;
  onReset: () => void;
  onAddAtPlayhead: () => void;
  onUpload: (file: File) => Promise<MediaInfo | null>;
  focusRange: (r: Range) => void;
}) {
  const { inserts, settings, setSettings } = props;
  const fileInput = useRef<HTMLInputElement>(null);
  const [target, setTarget] = useState<string | null>(null);
  const [uploading, setUploading] = useState<string | null>(null);
  const update = (id: string, patch: Partial<Insert>) => props.onChange(inserts.map((i) => (i.id === id ? { ...i, ...patch, auto: false } : i)));
  const thirds = [0, 1, 2].map((k) => props.outInserts.some((i) => i.a >= (props.outputDuration * k) / 3 && i.a < (props.outputDuration * (k + 1)) / 3));
  const visual = props.media.filter((m) => m.type !== "audio");

  return (
    <div className="panel-body">
      <Section title="Momentos de apoio" aside={<span className="count">{props.outInserts.length} no vídeo</span>}>
        <p className="note">Pelo menos três quebras visuais, uma em cada parte do vídeo. Por padrão viram um card com a frase que você está dizendo; troque por uma imagem ou um vídeo seu quando tiver.</p>
        <div className="thirds">
          {["Começo", "Meio", "Final"].map((label, k) => (
            <span key={label} className={thirds[k] ? "ok" : ""}>{thirds[k] ? <Check size={11} /> : null} {label}</span>
          ))}
        </div>
        <Switch
          checked={settings.autoInserts}
          onChange={(v) => setSettings((s) => ({ ...s, autoInserts: v }))}
          label="Sugerir os apoios sozinho"
          hint={props.transcriptReady ? "Escolhe frases curtas e com peso, uma em cada terço." : "Precisa da transcrição para escolher as frases."}
        />
      </Section>

      <div className="insert-list">
        {inserts.map((ins, n) => {
          const out = props.outInserts.find((o) => o.id === ins.id);
          const m = ins.mediaId ? props.media.find((x) => x.id === ins.mediaId) : undefined;
          return (
            <div key={ins.id} className={`insert-card ${out ? "" : "off"}`}>
              <header onClick={() => props.focusRange(ins)}>
                <span className="sg-icon zoom">{m ? (m.type === "video" ? <Film size={13} /> : <ImageIcon size={13} />) : <Type size={13} />}</span>
                <b>Apoio {n + 1}</b>
                <small>{out ? `${formatTime(out.a, true)} · ${(out.b - out.a).toFixed(1)}s` : "caiu num corte"}</small>
                <button className="sg-remove" title="Remover" onClick={(e) => { e.stopPropagation(); props.onChange(inserts.filter((i) => i.id !== ins.id)); }}><Trash2 size={14} /></button>
              </header>
              <Segmented
                value={m ? "media" : "card"}
                onChange={(v) => { if (v === "card") update(ins.id, { kind: "card", mediaId: null }); else { setTarget(ins.id); fileInput.current?.click(); } }}
                options={[{ value: "card", label: "Card com frase" }, { value: "media", label: uploading === ins.id ? "Enviando…" : m ? "Imagem/vídeo" : "Usar imagem/vídeo" }]}
              />
              {m ? (
                <div className="media-row">
                  {m.type === "image" ? <img src={m.url} alt="" /> : <video src={m.url} muted />}
                  <span className="sg-main"><b>{m.name}</b><small>{m.type === "video" ? "B-roll sem som" : "imagem com aproximação lenta"}</small></span>
                </div>
              ) : (
                <textarea className="input" rows={2} maxLength={120} value={ins.text} onChange={(e) => update(ins.id, { text: e.target.value })} onKeyDown={(e) => e.stopPropagation()} />
              )}
              {visual.length > 0 && !m && (
                <div className="media-pick">
                  {visual.map((v) => (
                    <button key={v.id} title={v.name} onClick={() => update(ins.id, { kind: "media", mediaId: v.id })}>
                      {v.type === "image" ? <img src={v.url} alt="" /> : <video src={v.url} muted />}
                    </button>
                  ))}
                </div>
              )}
              <Slider label="Duração" value={Math.round((ins.end - ins.start) * 10) / 10} min={0.8} max={5} step={0.1} format={(v) => `${v.toFixed(1)}s`} onChange={(v) => update(ins.id, { end: ins.start + v })} />
            </div>
          );
        })}
        {!inserts.length && <p className="empty">{props.transcriptReady ? "Nenhum apoio ainda." : "Sem transcrição, adicione os apoios à mão."}</p>}
      </div>

      <div className="row-buttons">
        <button className="btn" onClick={props.onAddAtPlayhead}><Plus size={14} /> Apoio na agulha</button>
        {props.customized && <button className="btn ghost" onClick={props.onReset}><RefreshCw size={14} /> Sugerir de novo</button>}
      </div>

      <Section title="Visual do card">
        <Segmented value={settings.card.background} onChange={(v) => setSettings((s) => ({ ...s, card: { ...s.card, background: v } }))} options={[{ value: "desfoque", label: "Vídeo desfocado" }, { value: "cor", label: "Cor sólida" }]} />
        <div className="colors">
          {settings.card.background === "cor" && <ColorField label="Fundo" value={settings.card.color} onChange={(v) => setSettings((s) => ({ ...s, card: { ...s.card, color: v } }))} />}
          <ColorField label="Texto" value={settings.card.textColor} onChange={(v) => setSettings((s) => ({ ...s, card: { ...s.card, textColor: v } }))} />
        </div>
        <p className="note">A palavra-chave do card usa a mesma cor de destaque da legenda.</p>
      </Section>

      <input ref={fileInput} type="file" accept="image/*,video/*" hidden onChange={async (e) => {
        const file = e.target.files?.[0];
        e.target.value = "";
        if (!file || !target) return;
        setUploading(target);
        const info = await props.onUpload(file);
        setUploading(null);
        if (info) update(target, { kind: "media", mediaId: info.id });
      }} />
    </div>
  );
}
