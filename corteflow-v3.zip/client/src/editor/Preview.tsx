import { useEffect, useLayoutEffect, useMemo, useRef, useState, type RefObject } from "react";
import type { CaptionStyle, CardStyle, FramingKey, Insert, MediaInfo, OutputZoom, ProjectInfo, Range, VideoFormat, Word } from "@shared/editor";
import { buildChunks, captionText, chunkEmphasis, clipToCards, faceInFrame, framingAt, inRanges, isKeyword, maxCharsFor, outputTimeAt, outputWords, zoomAtOutput } from "@shared/editor";

export const CSS_FONT: Record<CaptionStyle["font"], { family: string; weight: number }> = {
  montserrat: { family: "'Montserrat', sans-serif", weight: 800 },
  anton: { family: "'Anton', sans-serif", weight: 400 },
  poppins: { family: "'Poppins', sans-serif", weight: 700 },
};

type OutInsert = Insert & { a: number; b: number };

type Props = {
  videoRef: RefObject<HTMLVideoElement | null>;
  src: string;
  project: ProjectInfo;
  format: VideoFormat;
  currentTime: number;
  playing: boolean;
  showEdit: boolean;
  words: Word[];
  cuts: Range[];
  keep: Range[];
  outZooms: OutputZoom[];
  outInserts: OutInsert[];
  framing: FramingKey[];
  media: MediaInfo[];
  captions: CaptionStyle;
  card: CardStyle;
  hook: { text: string; duration: number } | null;
  onVideoError: () => void;
  onTime: (t: number) => void;
  onEnded: () => void;
};

export function aspectOf(format: VideoFormat, project: ProjectInfo) {
  if (format === "4:5") return 4 / 5;
  if (format === "1:1") return 1;
  if (format === "original") return (project.width || 9) / (project.height || 16);
  return 9 / 16;
}

function Emphasized({ words, index, color, style }: { words: string[]; index: number; color: string; style: Pick<CaptionStyle, "uppercase"> }) {
  return (
    <>
      {words.map((w, i) => (
        <span key={i} style={{ color: i === index ? color : undefined }}>
          {captionText(w, style)}{i < words.length - 1 ? " " : ""}
        </span>
      ))}
    </>
  );
}

export default function Preview(props: Props) {
  const { videoRef, src, project, format, currentTime, playing, showEdit, captions, hook, card } = props;
  const frameRef = useRef<HTMLDivElement>(null);
  const bgRef = useRef<HTMLVideoElement>(null);
  const insertVideoRef = useRef<HTMLVideoElement>(null);
  const aspect = aspectOf(format, project);
  const [box, setBox] = useState({ w: 300, h: 533 });
  useLayoutEffect(() => {
    const el = frameRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setBox({ w: el.clientWidth, h: el.clientHeight }));
    ro.observe(el);
    setBox({ w: el.clientWidth, h: el.clientHeight });
    return () => ro.disconnect();
  }, []);

  const chunks = useMemo(() => {
    if (!props.words.length) return [];
    return buildChunks(outputWords(props.words, props.cuts, props.keep), captions.maxWords, maxCharsFor(captions.size));
  }, [captions.maxWords, captions.size, props.words, props.cuts, props.keep]);

  const inCut = showEdit ? inRanges(currentTime, props.cuts) : null;
  const outTime = showEdit && !inCut ? outputTimeAt(currentTime, props.cuts, props.keep) : null;
  const insert = outTime === null ? null : props.outInserts.find((i) => outTime >= i.a && outTime < i.b) ?? null;
  const insertMedia = insert?.kind === "media" && insert.mediaId ? props.media.find((m) => m.id === insert.mediaId) : undefined;
  const isCard = insert && !insertMedia;
  const cardSpans = props.outInserts.filter((i) => !(i.kind === "media" && i.mediaId && props.media.some((m) => m.id === i.mediaId)));
  const chunk = outTime === null || !captions.enabled || isCard
    ? null
    : chunks.find((c) => { const v = clipToCards(c, cardSpans); return v && outTime >= v.start && outTime < v.end; }) ?? null;
  const zoom = outTime === null ? 1 : zoomAtOutput(outTime, props.outZooms);
  const showHook = showEdit && hook && hook.text.trim() && outTime !== null && outTime < hook.duration;

  // enquadramento: segue o rosto dentro do recorte vertical
  const face = framingAt(currentTime, props.framing);
  const sw = project.width || 1080, sh = project.height || 1920;
  const cover = format === "9:16" || format === "4:5" || format === "1:1";
  let objectPosition = "50% 40%";
  if (cover && props.framing.length) {
    const s = Math.max(box.w / sw, box.h / sh);
    const ow = sw * s, oh = sh * s;
    const cropX = Math.min(Math.max(face.x * ow - box.w / 2, 0), Math.max(0, ow - box.w));
    const cropY = Math.min(Math.max(face.y * oh - box.h * 0.4, 0), Math.max(0, oh - box.h));
    objectPosition = `${ow > box.w + 1 ? (cropX / (ow - box.w)) * 100 : 50}% ${oh > box.h + 1 ? (cropY / (oh - box.h)) * 100 : 50}%`;
  }
  const origin = faceInFrame(format, { t: 0, ...face }, sw, sh, box.w, box.h);

  // vídeo de fundo desfocado e B-roll acompanham o principal
  useEffect(() => {
    const bg = bgRef.current;
    const main = videoRef.current;
    if (bg && main) {
      if (Math.abs(bg.currentTime - main.currentTime) > 0.25) bg.currentTime = main.currentTime;
      if (playing && bg.paused) void bg.play().catch(() => undefined);
      if (!playing && !bg.paused) bg.pause();
    }
    const iv = insertVideoRef.current;
    if (iv && insert && outTime !== null) {
      const want = (outTime - insert.a) % Math.max(0.1, iv.duration || 999);
      if (Math.abs(iv.currentTime - want) > 0.3) iv.currentTime = want;
      if (playing && iv.paused) void iv.play().catch(() => undefined);
      if (!playing && !iv.paused) iv.pause();
    }
  }, [currentTime, playing, videoRef, insert, outTime]);

  const k = box.w / 1080;
  const font = CSS_FONT[captions.font];
  const fontSize = captions.size * k;
  const blur = format === "9:16-blur";
  const objectFit = blur || format === "original" ? "contain" : "cover";
  const outline = Math.max(1, fontSize * 0.05);
  const textShadow = captions.box
    ? "none"
    : [...[[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, -1], [1, -1], [-1, 1]].map(([x, y]) => `${x * outline}px ${y * outline}px 0 rgba(0,0,0,.85)`), `0 ${outline}px ${outline * 2.5}px rgba(0,0,0,.5)`].join(",");
  const position = captions.position === "cima" ? { top: "16%" } : captions.position === "meio" ? { top: "50%", transform: "translateY(-50%)" } : { bottom: "22%" };

  const falada = captions.emphasis === "falada";
  const chunkKey = chunk && captions.emphasis === "chave" ? chunkEmphasis(chunk) : -1;
  const cardWords = isCard ? insert!.text.trim().split(/\s+/).filter(Boolean) : [];
  const cardKey = cardWords.findIndex((w) => isKeyword(w));

  return (
    <div className="preview-frame" ref={frameRef} style={{ aspectRatio: String(aspect) }}>
      {blur && <video ref={bgRef} className="preview-bg" src={src} muted playsInline preload="auto" />}
      <video
        ref={videoRef}
        className="preview-video"
        src={src}
        playsInline
        preload="auto"
        style={{ objectFit, objectPosition, transform: zoom > 1.0005 ? `scale(${zoom})` : undefined, transformOrigin: `${origin.x * 100}% ${origin.y * 100}%` }}
        onError={props.onVideoError}
        onTimeUpdate={(e) => props.onTime(e.currentTarget.currentTime)}
        onSeeked={(e) => props.onTime(e.currentTarget.currentTime)}
        onEnded={props.onEnded}
      />

      {isCard && (
        <div className={`preview-card ${card.background === "cor" ? "solid" : ""}`} style={{ background: card.background === "cor" ? card.color : undefined }}>
          <span style={{ fontFamily: font.family, fontWeight: font.weight, fontSize: Math.min(120, captions.size * 1.2) * k, color: card.textColor }}>
            <Emphasized words={cardWords} index={cardKey} color={captions.highlightColor} style={captions} />
          </span>
        </div>
      )}
      {insertMedia?.type === "image" && <img className="preview-insert" src={insertMedia.url} alt="" />}
      {insertMedia?.type === "video" && <video ref={insertVideoRef} className="preview-insert" src={insertMedia.url} muted playsInline loop />}

      {showHook && (
        <div className="preview-hook" style={{ fontFamily: font.family, fontWeight: font.weight, fontSize: 56 * k, top: "12%" }}>
          <span>{hook!.text}</span>
        </div>
      )}
      {chunk && (
        <div className="preview-caption" style={{ ...position, fontFamily: font.family, fontWeight: font.weight, fontSize, lineHeight: 1.18 }}>
          <span
            style={{
              color: captions.textColor,
              textShadow,
              background: captions.box ? captions.boxColor : undefined,
              padding: captions.box ? `${fontSize * 0.12}px ${fontSize * 0.3}px` : undefined,
              borderRadius: captions.box ? fontSize * 0.12 : undefined,
              boxDecorationBreak: "clone",
              WebkitBoxDecorationBreak: "clone",
            }}
          >
            {chunk.words.map((w, i) => {
              const active = falada
                ? chunk.words.length > 1 && outTime! >= (i === 0 ? chunk.start : w.start) && (i === chunk.words.length - 1 || outTime! < chunk.words[i + 1].start)
                : i === chunkKey;
              return (
                <span key={i} style={{ color: active ? captions.highlightColor : undefined }}>
                  {captionText(w.text, captions)}{i < chunk.words.length - 1 ? " " : ""}
                </span>
              );
            })}
          </span>
        </div>
      )}
      {zoom > 1.0005 && !insert && <div className="preview-badge">zoom {zoom.toFixed(2)}×</div>}
      {insert && <div className="preview-badge blue">{insertMedia ? (insertMedia.type === "video" ? "B-roll" : "imagem de apoio") : "card"}</div>}
      {!showEdit && <div className="preview-badge left">original sem edição</div>}
      {inCut && !playing && <div className="preview-cut"><span>Trecho cortado</span><small>não entra no vídeo final</small></div>}
    </div>
  );
}
