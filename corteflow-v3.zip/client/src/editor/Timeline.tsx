import { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";
import { Minus, Plus, ScanLine } from "lucide-react";
import type { ProjectInfo, Range, Suggestion, ZoomRange } from "@shared/editor";
import { formatTime } from "@shared/editor";

type Props = {
  project: ProjectInfo;
  cuts: Range[];
  pending: Suggestion[];
  zooms: ZoomRange[];
  inserts: Array<Range & { kind: string; mediaId?: string | null }>;
  currentTime: number;
  playing: boolean;
  selection: Range | null;
  onSeek: (t: number) => void;
  onSelect: (r: Range | null) => void;
};

const H = 184;
const ROW = { ruler: [0, 20], film: [24, 76], wave: [80, 146], ins: [151, 164], zoom: [168, 181] } as const;
const COLORS = {
  bg: "#121417",
  lane: "#191c20",
  tick: "#3a3f46",
  label: "#7d838b",
  wave: "#c9d1d9",
  waveCut: "#5a2d2a",
  cut: "rgba(255, 92, 77, 0.16)",
  cutLine: "#ff5c4d",
  pending: "#f5b83d",
  zoom: "#f5b83d",
  zoomAuto: "rgba(245, 184, 61, 0.45)",
  sel: "rgba(120, 170, 255, 0.16)",
  selLine: "#7aa7ff",
  head: "#ff5c4d",
};

function niceStep(pps: number) {
  const steps = [0.5, 1, 2, 5, 10, 15, 30, 60, 120, 300];
  return steps.find((s) => s * pps >= 64) ?? 600;
}

export default function Timeline({ project, cuts, pending, zooms, inserts, currentTime, playing, selection, onSeek, onSelect }: Props) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [viewWidth, setViewWidth] = useState(800);
  const [scrollLeft, setScrollLeft] = useState(0);
  const [zoom, setZoom] = useState(1); // 1 = cabe na tela
  const [film, setFilm] = useState<HTMLImageElement | null>(null);
  const drag = useRef<{ x: number; t: number; moved: boolean } | null>(null);

  const duration = project.duration;
  const fitPps = Math.max(0.5, (viewWidth - 24) / duration);
  const pps = fitPps * zoom;
  const contentWidth = Math.max(viewWidth, duration * pps + 24);
  const xOf = useCallback((t: number) => 12 + t * pps - scrollLeft, [pps, scrollLeft]);
  const tOf = useCallback((x: number) => Math.min(duration, Math.max(0, (x + scrollLeft - 12) / pps)), [pps, scrollLeft, duration]);

  useLayoutEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setViewWidth(el.clientWidth));
    ro.observe(el);
    setViewWidth(el.clientWidth);
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    if (!project.filmstrip) return setFilm(null);
    const img = new Image();
    img.onload = () => setFilm(img);
    img.src = project.filmstrip.url;
  }, [project.filmstrip]);

  // Acompanha a agulha enquanto toca
  useEffect(() => {
    const el = scrollRef.current;
    if (!el || zoom <= 1) return;
    const x = 12 + currentTime * pps;
    if (playing && (x < el.scrollLeft + 40 || x > el.scrollLeft + el.clientWidth - 60)) el.scrollLeft = x - 80;
  }, [currentTime, playing, pps, zoom]);

  // Desenho
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.round(viewWidth * dpr);
    canvas.height = Math.round(H * dpr);
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, viewWidth, H);
    ctx.fillStyle = COLORS.bg;
    ctx.fillRect(0, 0, viewWidth, H);
    const x0 = Math.max(0, xOf(0));
    const x1 = Math.min(viewWidth, xOf(duration));

    // régua
    const step = niceStep(pps);
    ctx.font = "10px 'JetBrains Mono', ui-monospace, monospace";
    ctx.textBaseline = "middle";
    const firstTick = Math.floor(tOf(0) / step) * step;
    for (let t = firstTick; t <= duration + 0.001; t += step) {
      const x = xOf(t);
      if (x < -40 || x > viewWidth + 40) continue;
      ctx.fillStyle = COLORS.tick;
      ctx.fillRect(Math.round(x), 13, 1, 7);
      ctx.fillStyle = COLORS.label;
      ctx.fillText(formatTime(t), x + 4, 9);
      for (let k = 1; k < 4; k++) {
        const xs = xOf(t + (step * k) / 4);
        ctx.fillStyle = COLORS.tick;
        ctx.fillRect(Math.round(xs), 17, 1, 3);
      }
    }

    // trilhas
    ctx.fillStyle = COLORS.lane;
    for (const [a, b] of [ROW.film, ROW.wave, ROW.ins, ROW.zoom]) ctx.fillRect(x0, a, x1 - x0, b - a);

    // miniaturas
    if (film && project.filmstrip) {
      const { frames, frameWidth, frameHeight } = project.filmstrip;
      const h = ROW.film[1] - ROW.film[0];
      const w = (h * frameWidth) / frameHeight;
      ctx.save();
      ctx.beginPath();
      ctx.rect(x0, ROW.film[0], x1 - x0, h);
      ctx.clip();
      const startX = x0 - ((x0 - xOf(0)) % w);
      for (let x = startX; x < x1; x += w) {
        const t = tOf(x + w / 2);
        const idx = Math.min(frames - 1, Math.max(0, Math.floor((t / duration) * frames)));
        ctx.drawImage(film, idx * frameWidth, 0, frameWidth, frameHeight, x, ROW.film[0], w, h);
      }
      ctx.restore();
    }

    // forma de onda
    const env = project.envelope;
    const rate = project.envelopeRate;
    const mid = (ROW.wave[0] + ROW.wave[1]) / 2;
    const half = (ROW.wave[1] - ROW.wave[0]) / 2 - 3;
    let cutIdx = 0;
    for (let x = Math.floor(x0); x < x1; x++) {
      const ta = tOf(x);
      const tb = tOf(x + 1);
      let peak = -90;
      const ia = Math.floor(ta * rate);
      const ib = Math.max(ia + 1, Math.ceil(tb * rate));
      for (let i = ia; i < ib && i < env.length; i++) if (env[i] > peak) peak = env[i];
      const amp = Math.max(0.02, Math.min(1, (peak + 60) / 54));
      while (cutIdx < cuts.length && cuts[cutIdx].end < ta) cutIdx++;
      const cut = cutIdx < cuts.length && ta >= cuts[cutIdx].start && ta < cuts[cutIdx].end;
      ctx.fillStyle = cut ? COLORS.waveCut : COLORS.wave;
      const hgt = amp * half;
      ctx.fillRect(x, mid - hgt, 1, hgt * 2);
    }

    // cortes aplicados
    for (const c of cuts) {
      const a = xOf(c.start), b = xOf(c.end);
      if (b < 0 || a > viewWidth) continue;
      ctx.fillStyle = COLORS.cut;
      ctx.fillRect(a, ROW.film[0], Math.max(1, b - a), ROW.wave[1] - ROW.film[0]);
      ctx.save();
      ctx.beginPath();
      ctx.rect(a, ROW.film[0], Math.max(1, b - a), ROW.film[1] - ROW.film[0]);
      ctx.clip();
      ctx.fillStyle = "rgba(18,20,23,0.72)";
      ctx.fillRect(a, ROW.film[0], b - a, ROW.film[1] - ROW.film[0]);
      ctx.strokeStyle = "rgba(255,92,77,0.55)";
      ctx.lineWidth = 1;
      for (let s = a - 60; s < b; s += 7) {
        ctx.beginPath();
        ctx.moveTo(s, ROW.film[1]);
        ctx.lineTo(s + 52, ROW.film[0]);
        ctx.stroke();
      }
      ctx.restore();
      ctx.fillStyle = COLORS.cutLine;
      ctx.fillRect(a, ROW.film[0], Math.max(1, b - a), 2);
    }

    // sugestões ainda não aplicadas
    ctx.setLineDash([3, 3]);
    ctx.strokeStyle = COLORS.pending;
    for (const s of pending) {
      const a = xOf(s.start), b = xOf(s.end);
      if (b < 0 || a > viewWidth) continue;
      ctx.strokeRect(a + 0.5, ROW.wave[0] + 0.5, Math.max(2, b - a - 1), ROW.wave[1] - ROW.wave[0] - 1);
    }
    ctx.setLineDash([]);

    // zooms
    for (const z of zooms) {
      const a = xOf(z.start), b = xOf(z.end);
      if (b < 0 || a > viewWidth) continue;
      const r = 3;
      const w = Math.max(2, b - a - 2);
      if (z.ramp) {
        const g = ctx.createLinearGradient(a, 0, a + Math.min(w, 4 * pps), 0);
        g.addColorStop(0, "rgba(245, 184, 61, 0.08)");
        g.addColorStop(1, z.auto ? COLORS.zoomAuto : COLORS.zoom);
        ctx.fillStyle = g;
      } else ctx.fillStyle = z.auto ? COLORS.zoomAuto : COLORS.zoom;
      ctx.beginPath();
      ctx.roundRect(a + 1, ROW.zoom[0], w, ROW.zoom[1] - ROW.zoom[0], r);
      ctx.fill();
      if (w > 34) {
        ctx.fillStyle = "#1a1407";
        ctx.font = "600 9px 'JetBrains Mono', ui-monospace, monospace";
        ctx.fillText(`${z.scale.toFixed(2)}×`, a + 5, (ROW.zoom[0] + ROW.zoom[1]) / 2 + 0.5);
      }
    }

    // apoios (cards, imagens, B-roll)
    for (const ins of inserts) {
      const a = xOf(ins.start), b = xOf(ins.end);
      if (b < 0 || a > viewWidth) continue;
      ctx.fillStyle = ins.mediaId ? "#5b8cff" : "rgba(122, 167, 255, 0.55)";
      ctx.beginPath();
      ctx.roundRect(a + 1, ROW.ins[0], Math.max(2, b - a - 2), ROW.ins[1] - ROW.ins[0], 3);
      ctx.fill();
      if (b - a > 40) {
        ctx.fillStyle = "#0d1426";
        ctx.font = "600 9px 'JetBrains Mono', ui-monospace, monospace";
        ctx.fillText(ins.mediaId ? "B-ROLL" : "CARD", a + 5, (ROW.ins[0] + ROW.ins[1]) / 2 + 0.5);
      }
    }

    // seleção
    if (selection) {
      const a = xOf(selection.start), b = xOf(selection.end);
      ctx.fillStyle = COLORS.sel;
      ctx.fillRect(a, ROW.ruler[1], b - a, H - ROW.ruler[1]);
      ctx.fillStyle = COLORS.selLine;
      ctx.fillRect(a, ROW.ruler[1], 1.5, H - ROW.ruler[1]);
      ctx.fillRect(b - 1.5, ROW.ruler[1], 1.5, H - ROW.ruler[1]);
    }

    // agulha
    const hx = xOf(currentTime);
    if (hx >= -2 && hx <= viewWidth + 2) {
      ctx.fillStyle = COLORS.head;
      ctx.fillRect(Math.round(hx) - 0.5, 4, 2, H - 4);
      ctx.beginPath();
      ctx.moveTo(hx - 5, 2);
      ctx.lineTo(hx + 6, 2);
      ctx.lineTo(hx + 0.5, 10);
      ctx.closePath();
      ctx.fill();
    }
  }, [viewWidth, scrollLeft, pps, project, film, cuts, pending, zooms, inserts, selection, currentTime, xOf, tOf, duration]);

  const localX = (e: React.PointerEvent) => e.clientX - (canvasRef.current?.getBoundingClientRect().left ?? 0);

  const onPointerDown = (e: React.PointerEvent) => {
    (e.target as Element).setPointerCapture(e.pointerId);
    const x = localX(e);
    drag.current = { x, t: tOf(x), moved: false };
  };
  const onPointerMove = (e: React.PointerEvent) => {
    if (!drag.current) return;
    const x = localX(e);
    if (Math.abs(x - drag.current.x) > 4) drag.current.moved = true;
    if (drag.current.moved) {
      const t = tOf(x);
      onSelect({ start: Math.min(t, drag.current.t), end: Math.max(t, drag.current.t) });
    }
  };
  const onPointerUp = (e: React.PointerEvent) => {
    if (!drag.current) return;
    if (!drag.current.moved) {
      onSelect(null);
      onSeek(tOf(localX(e)));
    }
    drag.current = null;
  };

  const setZoomAround = (next: number, anchorX = viewWidth / 2) => {
    const clamped = Math.min(80, Math.max(1, next));
    const t = tOf(anchorX);
    setZoom(clamped);
    requestAnimationFrame(() => {
      const el = scrollRef.current;
      if (!el) return;
      el.scrollLeft = 12 + t * fitPps * clamped - anchorX;
    });
  };

  const zoomRef = useRef(setZoomAround);
  zoomRef.current = setZoomAround;
  const zoomValue = useRef(zoom);
  zoomValue.current = zoom;
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      if (!(e.ctrlKey || e.metaKey)) return;
      e.preventDefault();
      zoomRef.current(zoomValue.current * (e.deltaY < 0 ? 1.25 : 0.8), e.clientX - el.getBoundingClientRect().left);
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, []);

  return (
    <div className="timeline">
      <div className="timeline-bar">
        <div className="timeline-legend">
          <span><i className="lg-cut" /> cortado</span>
          <span><i className="lg-pending" /> sugestão em revisão</span>
          <span><i className="lg-ins" /> apoio</span>
          <span><i className="lg-zoom" /> zoom</span>
          <span className="muted">arraste para selecionar um trecho</span>
        </div>
        <div className="timeline-zoom">
          <button onClick={() => setZoomAround(zoom / 1.6)} aria-label="Afastar"><Minus size={14} /></button>
          <button onClick={() => setZoomAround(1)} className="fit" aria-label="Ajustar à tela"><ScanLine size={14} /> ajustar</button>
          <button onClick={() => setZoomAround(zoom * 1.6)} aria-label="Aproximar"><Plus size={14} /></button>
        </div>
      </div>
      <div
        className="timeline-scroll"
        ref={scrollRef}
        onScroll={(e) => setScrollLeft(e.currentTarget.scrollLeft)}
      >
        <div style={{ width: contentWidth, height: H }}>
          <canvas
            ref={canvasRef}
            style={{ width: viewWidth, height: H, position: "sticky", left: 0, display: "block", touchAction: "none" }}
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
          />
        </div>
      </div>
    </div>
  );
}
