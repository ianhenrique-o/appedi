import type { FramingKey } from "@shared/editor";
import { smoothFraming } from "@shared/editor";

type FaceApi = typeof import("@vladmandic/face-api");
let loading: Promise<FaceApi> | null = null;

async function loadFaceApi() {
  loading ??= (async () => {
    const faceapi = await import("@vladmandic/face-api");
    const tf = faceapi.tf as unknown as { setBackend: (b: string) => Promise<boolean>; ready: () => Promise<void> };
    // WebGL é o rápido; sem ele (máquina sem aceleração) usa a CPU, mais lenta mas funciona
    let ok = false;
    try { ok = await tf.setBackend("webgl"); } catch { ok = false; }
    if (!ok) await tf.setBackend("cpu");
    await tf.ready();
    await faceapi.nets.tinyFaceDetector.loadFromUri("/models");
    return faceapi;
  })();
  return loading;
}

function seek(video: HTMLVideoElement, t: number) {
  return new Promise<void>((resolve) => {
    const done = () => { video.removeEventListener("seeked", done); resolve(); };
    video.addEventListener("seeked", done);
    video.currentTime = t;
    window.setTimeout(done, 1500);
  });
}

/**
 * Passa pelo vídeo de meio em meio segundo procurando o rosto e devolve
 * uma "câmera" suave: só se mexe quando a pessoa sai do lugar.
 */
export async function trackFace(src: string, duration: number, onProgress: (p: number) => void, signal?: AbortSignal): Promise<{ keys: FramingKey[]; found: number; samples: number }> {
  const faceapi = await loadFaceApi();
  const video = document.createElement("video");
  video.muted = true;
  video.playsInline = true;
  video.preload = "auto";
  video.crossOrigin = "anonymous";
  video.src = src;
  await new Promise<void>((resolve, reject) => {
    video.onloadeddata = () => resolve();
    video.onerror = () => reject(new Error("Não consegui abrir o vídeo para enquadrar."));
  });
  const canvas = document.createElement("canvas");
  const scale = 360 / Math.max(video.videoWidth, video.videoHeight);
  canvas.width = Math.round(video.videoWidth * scale);
  canvas.height = Math.round(video.videoHeight * scale);
  const ctx = canvas.getContext("2d", { willReadFrequently: true })!;
  const step = duration > 180 ? 1 : 0.5;
  const options = new faceapi.TinyFaceDetectorOptions({ inputSize: 320, scoreThreshold: 0.45 });
  const raw: Array<{ t: number; x: number; y: number } | { t: number; x: null; y: null }> = [];
  let found = 0;
  for (let t = 0.05; t < duration; t += step) {
    if (signal?.aborted) break;
    await seek(video, t);
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const faces = await faceapi.detectAllFaces(canvas, options);
    if (faces.length) {
      // o maior rosto é quem está falando
      const best = faces.reduce((a, b) => (b.box.area > a.box.area ? b : a));
      raw.push({ t, x: (best.box.x + best.box.width / 2) / canvas.width, y: (best.box.y + best.box.height / 2) / canvas.height });
      found++;
    } else raw.push({ t, x: null, y: null });
    onProgress(Math.min(1, t / duration));
  }
  video.removeAttribute("src");
  video.load();
  return { keys: smoothFraming(raw), found, samples: raw.length };
}
