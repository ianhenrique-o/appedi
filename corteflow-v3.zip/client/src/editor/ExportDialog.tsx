import { useEffect, useRef, useState } from "react";
import { Download, Loader2, RefreshCw, X } from "lucide-react";
import type { JobState, RenderRequest } from "@shared/editor";
import { formatTime } from "@shared/editor";
import { getJob, startRender } from "./api";
import { Segmented } from "./controls";

type Props = {
  projectId: string;
  defaultName: string;
  buildRequest: () => RenderRequest;
  summary: { duration: number; cuts: number; zooms: number; inserts: number; captions: boolean; format: string };
  quality: "rapida" | "alta";
  setQuality: (q: "rapida" | "alta") => void;
  onClose: () => void;
};

export default function ExportDialog({ projectId, defaultName, buildRequest, summary, quality, setQuality, onClose }: Props) {
  const [name, setName] = useState(defaultName);
  const [job, setJob] = useState<JobState | null>(null);
  const [error, setError] = useState("");
  const timer = useRef<number | null>(null);

  useEffect(() => () => { if (timer.current) window.clearTimeout(timer.current); }, []);

  const poll = (id: string) => {
    timer.current = window.setTimeout(async () => {
      try {
        const next = await getJob(id);
        setJob(next);
        if (next.state === "fila" || next.state === "renderizando") poll(id);
      } catch (e) {
        setError(e instanceof Error ? e.message : "Perdi o contato com o servidor.");
      }
    }, 700);
  };

  const start = async () => {
    setError("");
    try {
      const created = await startRender(projectId, { ...buildRequest(), fileName: name, quality });
      setJob(created);
      poll(created.id);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Não consegui começar a exportação.");
    }
  };

  const busy = job && (job.state === "fila" || job.state === "renderizando");
  const done = job?.state === "pronto";

  return (
    <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget && !busy) onClose(); }}>
      <div className="modal" role="dialog" aria-label="Exportar vídeo">
        <header>
          <h2>{done ? "Seu Reel está pronto" : "Exportar"}</h2>
          <button className="icon-btn" onClick={onClose} aria-label="Fechar"><X size={16} /></button>
        </header>

        {!job && (
          <>
            <div className="export-summary">
              <div><small>Duração final</small><b>{formatTime(summary.duration)}</b></div>
              <div><small>Cortes</small><b>{summary.cuts}</b></div>
              <div><small>Zooms</small><b>{summary.zooms}</b></div>
              <div><small>Apoios</small><b>{summary.inserts}</b></div>
              <div><small>Formato</small><b>{summary.format}</b></div>
            </div>
            {!summary.captions && <p className="note">Esse vídeo vai sair sem legenda.</p>}
            {summary.inserts < 3 && <p className="note">O padrão pede pelo menos 3 momentos de apoio. Hoje há {summary.inserts}; dá para adicionar na aba Apoios.</p>}
            <label className="field-label" htmlFor="export-name">Nome do arquivo</label>
            <input id="export-name" className="input" value={name} onChange={(e) => setName(e.target.value)} onKeyDown={(e) => e.stopPropagation()} />
            <div className="field-label">Qualidade</div>
            <Segmented value={quality} onChange={setQuality} options={[{ value: "rapida", label: "Rápida (recomendada)" }, { value: "alta", label: "Máxima (demora mais)" }]} />
            {error && <p className="error-text">{error}</p>}
            <button className="btn primary wide" onClick={start}>Renderizar vídeo</button>
          </>
        )}

        {busy && (
          <div className="export-progress">
            <Loader2 className="spin" size={20} />
            <b>{job!.state === "fila" ? "Na fila…" : `${job!.stage}… ${Math.round(job!.progress * 100)}%`}</b>
            <div className="bar"><span style={{ width: `${Math.max(3, job!.progress * 100)}%` }} /></div>
            <p className="note">Pode continuar mexendo no editor. Mudanças feitas agora entram na próxima exportação.</p>
          </div>
        )}

        {done && (
          <div className="export-done">
            <video src={`${job!.downloadUrl}?inline=1`} controls playsInline />
            <a className="btn primary wide" href={job!.downloadUrl} download={job!.fileName}><Download size={16} /> Baixar {job!.fileName}</a>
            {job!.srtUrl && <a className="btn wide" href={job!.srtUrl} download><Download size={14} /> Baixar legendas (.srt)</a>}
            <button className="btn ghost wide" onClick={() => setJob(null)}><RefreshCw size={14} /> Exportar de novo</button>
          </div>
        )}

        {job?.state === "erro" && (
          <div className="export-progress">
            <p className="error-text">A renderização falhou: {job.error}</p>
            <button className="btn" onClick={() => setJob(null)}>Voltar</button>
          </div>
        )}
      </div>
    </div>
  );
}
